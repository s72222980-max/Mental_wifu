import { Telegraf } from "telegraf";

let _bot: Telegraf | null = null;

export function getBot(): Telegraf {
  if (!_bot) {
    const token = process.env.TELEGRAM_BOT_TOKEN;
    if (!token) throw new Error("TELEGRAM_BOT_TOKEN environment variable is required");
    _bot = new Telegraf(token);
  }
  return _bot;
}

// Lazy proxy — accessed as `bot` throughout codebase
export const bot = new Proxy({} as Telegraf, {
  get(_target, prop) {
    return (getBot() as unknown as Record<string, unknown>)[prop as string];
  },
});
