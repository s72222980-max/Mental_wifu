import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botUsersTable, botUserCharactersTable } from "@workspace/db";
import { eq, desc, count } from "drizzle-orm";
import { getOrCreateUser, getUserByTelegramId, getUserByUsername, checkPremium, getRarityEmoji, escapeHtml } from "../utils";

export async function handleCheck(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.message) return;

  const text = "text" in ctx.message ? ctx.message.text : "";
  const parts = text.trim().split(/\s+/).slice(1);
  const replyTo = "reply_to_message" in ctx.message ? ctx.message.reply_to_message : null;

  let targetTelegramId: string | null = null;

  if (replyTo && replyTo.from && !replyTo.from.is_bot) {
    targetTelegramId = String(replyTo.from.id);
  } else if (parts[0]?.startsWith("@")) {
    const found = await getUserByUsername(parts[0].slice(1));
    if (!found) {
      await ctx.reply(`❌ User <b>${escapeHtml(parts[0])}</b> not found in the bot!`, { parse_mode: "HTML" });
      return;
    }
    targetTelegramId = found.telegramId;
  } else {
    targetTelegramId = String(ctx.from.id);
  }

  const target = await getUserByTelegramId(targetTelegramId!);
  if (!target) {
    await ctx.reply("❌ User not found! They need to /start the bot first.");
    return;
  }

  const [collectionCount, rankRows] = await Promise.all([
    db.select({ count: count() }).from(botUserCharactersTable).where(eq(botUserCharactersTable.userId, target.id)),
    db.select({ id: botUsersTable.id }).from(botUsersTable).orderBy(desc(botUsersTable.totalCaught)),
  ]);

  const rank = rankRows.findIndex((r) => r.id === target.id) + 1;
  const isPremium = await checkPremium(target.telegramId);
  const badge = isPremium ? " 🌟" : "";
  const nameDisplay = target.username ? `@${escapeHtml(target.username)}` : escapeHtml(target.firstName);

  await ctx.reply(
    `🔍 <b>User Info${badge}</b>\n\n` +
      `👤 <b>Name:</b> ${nameDisplay}\n` +
      `💰 <b>Coins:</b> ${target.coins.toLocaleString()}\n` +
      `🎴 <b>Total Caught:</b> ${target.totalCaught}\n` +
      `📦 <b>Collection:</b> ${Number(collectionCount[0]?.count ?? 0)} cards\n` +
      `🏆 <b>Rank:</b> #${rank}\n` +
      `🔥 <b>Streak:</b> ${target.streakDays} day${target.streakDays !== 1 ? "s" : ""}`,
    { parse_mode: "HTML" },
  );
}
