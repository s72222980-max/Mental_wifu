import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botUsersTable, botCharactersTable, botUserCharactersTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { getOrCreateUser, getRarityEmoji, getRarityLabel, escapeHtml } from "../utils";

const COOLDOWN_MS = 24 * 60 * 60 * 1000;

export async function handleSuperBonus(ctx: Context): Promise<void> {
  if (!ctx.from) return;
  const user = await getOrCreateUser(ctx.from);

  // 24h cooldown check
  if (user.lastSuperBonusAt) {
    const elapsed = Date.now() - new Date(user.lastSuperBonusAt).getTime();
    if (elapsed < COOLDOWN_MS) {
      const remaining = COOLDOWN_MS - elapsed;
      const hrs = Math.floor(remaining / 3_600_000);
      const mins = Math.floor((remaining % 3_600_000) / 60_000);
      await ctx.reply(
        `⏳ <b>Super Bonus already claimed!</b>\n\n` +
        `Next claim in: <b>${hrs}h ${mins}m</b>\n\n` +
        `<i>Come back tomorrow for another character!</i>`,
        { parse_mode: "HTML" },
      );
      return;
    }
  }

  // Pick a random character (any rarity, weighted toward rare+)
  const roll = Math.random() * 100;
  let rarity: string;
  if (roll < 30) rarity = "rare";
  else if (roll < 65) rarity = "epic";
  else rarity = "legendary";

  let chars = await db.select().from(botCharactersTable)
    .where(eq(botCharactersTable.rarity, rarity))
    .orderBy(sql`RANDOM()`)
    .limit(1);

  if (chars.length === 0) {
    chars = await db.select().from(botCharactersTable).orderBy(sql`RANDOM()`).limit(1);
  }

  const character = chars[0];
  if (!character) {
    await ctx.reply("❌ No characters available right now. Try again later!", { parse_mode: "HTML" });
    return;
  }

  // Add character to user's harem
  const [newUc] = await db.insert(botUserCharactersTable)
    .values({ userId: user.id, characterId: character.id })
    .returning();

  // Update cooldown timestamp
  await db.update(botUsersTable)
    .set({ lastSuperBonusAt: new Date() })
    .where(eq(botUsersTable.id, user.id));

  const ucId = newUc?.id ?? 0;

  const caption =
    `🎁 <b>Super Bonus Claimed!</b>\n\n` +
    `${getRarityEmoji(character.rarity)} <b>${escapeHtml(character.name)}</b>\n` +
    `🎭 <b>Anime:</b> ${escapeHtml(character.anime)}\n` +
    `✨ <b>Rarity:</b> ${getRarityLabel(character.rarity)}\n` +
    `🆔 <b>Collection ID:</b> #${ucId}\n\n` +
    `<i>Come back in 24 hours for another character!</i>\n` +
    `Use /view ${ucId} to see it anytime!`;

  try {
    await ctx.replyWithPhoto(character.imageUrl, { caption, parse_mode: "HTML" });
  } catch {
    await ctx.reply(caption, { parse_mode: "HTML" });
  }
}
