import type { Context } from "telegraf";
import { db } from "@workspace/db";
import {
  botSudoUsersTable,
  botBannedUsersTable,
  botUsersTable,
  botCharactersTable,
  botUserCharactersTable,
} from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";
import { isOwner, isSudoAdmin, getUserByUsername, escapeHtml } from "../utils";
import { reseedCharacters } from "../seed";
import { bot } from "../bot-instance";
import { handleStats } from "./stats";

async function resolveTarget(ctx: Context): Promise<{ telegramId: string; name: string } | null> {
  if (!ctx.message) return null;
  const text = "text" in ctx.message ? ctx.message.text : "";
  const replyTo = "reply_to_message" in ctx.message ? ctx.message.reply_to_message : null;
  const parts = text.trim().split(/\s+/).slice(2);

  if (replyTo?.from && !replyTo.from.is_bot) {
    return { telegramId: String(replyTo.from.id), name: replyTo.from.first_name };
  }
  const mention = parts[0];
  if (mention?.startsWith("@")) {
    const found = await getUserByUsername(mention.slice(1));
    if (found) return { telegramId: found.telegramId, name: found.firstName };
  } else if (mention && /^\d+$/.test(mention)) {
    return { telegramId: mention, name: mention };
  }
  return null;
}

export async function handleSudo(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.message) return;

  if (!(await isSudoAdmin(String(ctx.from.id)))) {
    await ctx.reply("❌ Sudo-only command!");
    return;
  }

  const text = "text" in ctx.message ? ctx.message.text : "";
  const parts = text.trim().split(/\s+/).slice(1);
  const subCmd = parts[0]?.toLowerCase();

  if (!subCmd) {
    await ctx.reply(
      `👑 <b>Sudo Commands:</b>\n\n` +
        `/sudo coins @user &lt;amount&gt; — Give coins\n` +
        `/sudo ban @user [reason] — Ban user\n` +
        `/sudo unban @user — Unban user\n` +
        `/sudo reseed — Reseed character DB\n` +
        `/sudo broadcast &lt;msg&gt; — Broadcast to all users\n` +
        `/sudo stats — Bot statistics`,
      { parse_mode: "HTML" },
    );
    return;
  }

  if (subCmd === "stats") {
    await handleStats(ctx);
    return;
  }

  if (subCmd === "reseed") {
    if (!isOwner(String(ctx.from.id))) { await ctx.reply("❌ Only owner can reseed!"); return; }
    await ctx.reply("🌱 Reseeding characters... This may take a while!");
    try {
      await reseedCharacters();
      await ctx.reply("✅ Characters reseeded successfully!");
    } catch (err) {
      await ctx.reply(`❌ Reseed failed: ${String(err)}`);
    }
    return;
  }

  if (subCmd === "coins") {
    const target = await resolveTarget(ctx);
    const amountStr = parts[2] ?? parts[1];
    const amount = parseInt(amountStr ?? "");
    if (!target || isNaN(amount)) {
      await ctx.reply("❌ Usage: /sudo coins @user &lt;amount&gt;", { parse_mode: "HTML" });
      return;
    }
    const rows = await db.select().from(botUsersTable).where(eq(botUsersTable.telegramId, target.telegramId)).limit(1);
    const user = rows[0];
    if (!user) { await ctx.reply("❌ User not found!"); return; }
    await db.update(botUsersTable).set({ coins: user.coins + amount }).where(eq(botUsersTable.id, user.id));
    await ctx.reply(`✅ Gave <b>${amount} coins</b> to <b>${escapeHtml(target.name)}</b>!`, { parse_mode: "HTML" });
    return;
  }

  if (subCmd === "ban") {
    const target = await resolveTarget(ctx);
    const reason = parts.slice(2).join(" ") || "No reason";
    if (!target) { await ctx.reply("❌ Usage: /sudo ban @user [reason]"); return; }
    await db.insert(botBannedUsersTable).values({ telegramId: target.telegramId, reason, bannedBy: String(ctx.from.id) }).onConflictDoNothing();
    await ctx.reply(`✅ <b>${escapeHtml(target.name)}</b> has been banned!\nReason: ${escapeHtml(reason)}`, { parse_mode: "HTML" });
    return;
  }

  if (subCmd === "unban") {
    const target = await resolveTarget(ctx);
    if (!target) { await ctx.reply("❌ Usage: /sudo unban @user"); return; }
    await db.delete(botBannedUsersTable).where(eq(botBannedUsersTable.telegramId, target.telegramId));
    await ctx.reply(`✅ <b>${escapeHtml(target.name)}</b> has been unbanned!`, { parse_mode: "HTML" });
    return;
  }

  if (subCmd === "broadcast") {
    if (!isOwner(String(ctx.from.id))) { await ctx.reply("❌ Only owner can broadcast!"); return; }
    const message = parts.slice(1).join(" ");
    if (!message) { await ctx.reply("❌ Usage: /sudo broadcast &lt;message&gt;", { parse_mode: "HTML" }); return; }

    const users = await db.select({ telegramId: botUsersTable.telegramId }).from(botUsersTable);
    let sent = 0;
    let failed = 0;
    for (const user of users) {
      try {
        await bot.telegram.sendMessage(user.telegramId, `📢 <b>Broadcast</b>\n\n${message}`, { parse_mode: "HTML" });
        sent++;
      } catch { failed++; }
      await new Promise((r) => setTimeout(r, 50));
    }
    await ctx.reply(`✅ Broadcast sent!\n✅ ${sent} success | ❌ ${failed} failed`);
    return;
  }

  await ctx.reply("❌ Unknown sudo subcommand.");
}

export async function handleAddSudo(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.message) return;
  if (!isOwner(String(ctx.from.id))) { await ctx.reply("❌ Only owner can grant sudo!"); return; }

  const text = "text" in ctx.message ? ctx.message.text : "";
  const replyTo = "reply_to_message" in ctx.message ? ctx.message.reply_to_message : null;
  const mention = text.trim().split(/\s+/)[1];

  let telegramId: string | null = null;
  let name = "Unknown";

  if (replyTo?.from && !replyTo.from.is_bot) {
    telegramId = String(replyTo.from.id);
    name = replyTo.from.first_name;
  } else if (mention?.startsWith("@")) {
    const found = await getUserByUsername(mention.slice(1));
    if (found) { telegramId = found.telegramId; name = found.firstName; }
  } else if (mention && /^\d+$/.test(mention)) {
    telegramId = mention;
    name = mention;
  }

  if (!telegramId) { await ctx.reply("❌ Reply to a user or mention @username!"); return; }

  await db.insert(botSudoUsersTable).values({ telegramId, grantedBy: String(ctx.from.id) }).onConflictDoNothing();
  await ctx.reply(`✅ <b>${escapeHtml(name)}</b> is now a sudo admin!`, { parse_mode: "HTML" });
}

export async function handleRemoveSudo(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.message) return;
  if (!isOwner(String(ctx.from.id))) { await ctx.reply("❌ Only owner can remove sudo!"); return; }

  const text = "text" in ctx.message ? ctx.message.text : "";
  const replyTo = "reply_to_message" in ctx.message ? ctx.message.reply_to_message : null;
  const mention = text.trim().split(/\s+/)[1];

  let telegramId: string | null = null;
  let name = "Unknown";

  if (replyTo?.from && !replyTo.from.is_bot) {
    telegramId = String(replyTo.from.id);
    name = replyTo.from.first_name;
  } else if (mention?.startsWith("@")) {
    const found = await getUserByUsername(mention.slice(1));
    if (found) { telegramId = found.telegramId; name = found.firstName; }
  }

  if (!telegramId) { await ctx.reply("❌ Reply to a user or mention @username!"); return; }

  await db.delete(botSudoUsersTable).where(eq(botSudoUsersTable.telegramId, telegramId));
  await ctx.reply(`✅ Sudo removed from <b>${escapeHtml(name)}</b>!`, { parse_mode: "HTML" });
}

export async function handleSudoList(ctx: Context): Promise<void> {
  if (!ctx.from) return;
  if (!isOwner(String(ctx.from.id))) { await ctx.reply("❌ Only owner can view sudo list!"); return; }

  const rows = await db.select().from(botSudoUsersTable);

  if (rows.length === 0) {
    await ctx.reply("📋 No sudo admins.");
    return;
  }

  const lines = rows.map((r, i) => `${i + 1}. <code>${r.telegramId}</code>`);
  await ctx.reply(`👑 <b>Sudo Admins (${rows.length})</b>\n\n${lines.join("\n")}`, { parse_mode: "HTML" });
}
