import type { Context } from "telegraf";
import { isGroupAdmin, checkPremium } from "../utils";
import { spawnCharacter, getActiveSpawnForGroup } from "../spawn";
import { bot } from "../bot-instance";

export async function handleDrop(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.chat) return;

  if (ctx.chat.type !== "group" && ctx.chat.type !== "supergroup") {
    await ctx.reply("⚠️ /drop only works in groups!");
    return;
  }

  const admin = await isGroupAdmin(ctx);
  const premium = await checkPremium(String(ctx.from.id));

  if (!admin && !premium) {
    await ctx.reply("❌ Only group admins or 🌟 Premium users can use /drop!");
    return;
  }

  const groupId = String(ctx.chat.id);
  const existing = await getActiveSpawnForGroup(groupId);

  if (existing) {
    await ctx.reply("⚠️ A character is already active! Guess their name first.");
    return;
  }

  await ctx.reply("⚡ Dropping a character...");
  await spawnCharacter(bot, groupId);
}
