import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botUsersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getOrCreateUser, escapeHtml, PE } from "../utils";

const COOLDOWN_MS = 24 * 60 * 60 * 1000;
const STREAK_BREAK_MS = 48 * 60 * 60 * 1000;
const BASE_COINS = 100;
const STREAK_BONUS = 50;
const MAX_BONUS = 500;

function calcReward(streak: number): number {
  return Math.min(BASE_COINS + streak * STREAK_BONUS, MAX_BONUS);
}

function msToHMS(ms: number): string {
  const h = Math.floor(ms / 3_600_000);
  const m = Math.floor((ms % 3_600_000) / 60_000);
  const s = Math.floor((ms % 60_000) / 1_000);
  return `${h}h ${m}m ${s}s`;
}

export async function handleDaily(ctx: Context): Promise<void> {
  if (!ctx.from) return;
  const user = await getOrCreateUser(ctx.from);

  const now = Date.now();
  const lastMs = user.lastDailyAt ? user.lastDailyAt.getTime() : 0;
  const elapsed = now - lastMs;

  if (elapsed < COOLDOWN_MS) {
    const remaining = COOLDOWN_MS - elapsed;
    await ctx.reply(
      `${PE.hourglass} <b>Daily already claimed!</b>\n\nNext reward in: <b>${msToHMS(remaining)}</b>\n\n` +
        `${PE.fire} Current streak: <b>${user.streakDays} day${user.streakDays !== 1 ? "s" : ""}</b>\n` +
      `<blockquote>Come back soon to keep your streak alive!</blockquote>`,
      { parse_mode: "HTML" },
    );
    return;
  }

  const streakBroken = lastMs > 0 && elapsed > STREAK_BREAK_MS;
  const newStreak = streakBroken ? 1 : user.streakDays + 1;
  const reward = calcReward(newStreak - 1);

  await db
    .update(botUsersTable)
    .set({
      coins: user.coins + reward,
      streakDays: newStreak,
      lastDailyAt: new Date(now),
    })
    .where(eq(botUsersTable.id, user.id));

  const streakMsg = streakBroken
    ? `\n💔 <i>Streak reset! Come back daily to keep it going.</i>`
    : newStreak > 1
      ? `\n🔥 <b>${newStreak} day streak!</b> Keep it up!`
      : "";

  const nextReward = calcReward(newStreak);

  await ctx.reply(
    `${PE.gift} <b>Daily Reward Claimed!</b>\n\n` +
      `<b>${escapeHtml(ctx.from.first_name)}</b> received <b>${PE.coin} ${reward} coins</b>!\n` +
      `💼 <b>Balance:</b> ${user.coins + reward} coins\n` +
      `${PE.fire} <b>Streak:</b> ${newStreak} day${newStreak !== 1 ? "s" : ""}${streakMsg}\n\n` +
      `<blockquote>Next reward: ${PE.coin} ${nextReward} coins | Claim again in 24h</blockquote>`,
    { parse_mode: "HTML" },
  );
}
