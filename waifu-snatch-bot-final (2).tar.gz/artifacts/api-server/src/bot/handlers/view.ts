import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botUserCharactersTable, botCharactersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { getOrCreateUser, getRarityEmoji, getRarityLabel, escapeHtml, formatDate } from "../utils";

export async function handleView(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.message) return;

  const text = "text" in ctx.message ? ctx.message.text : "";
  const charIdStr = text.trim().split(/\s+/)[1];

  if (!charIdStr) {
    await ctx.reply(
      "🔍 <b>View Usage:</b>\n\n<code>/view [collection_id]</code>\n\nUse /harem to find character IDs.",
      { parse_mode: "HTML" },
    );
    return;
  }

  const charId = parseInt(charIdStr);
  if (isNaN(charId)) { await ctx.reply("❌ Invalid ID!"); return; }

  const user = await getOrCreateUser(ctx.from);

  const rows = await db
    .select({
      ucId: botUserCharactersTable.id,
      name: botCharactersTable.name,
      anime: botCharactersTable.anime,
      rarity: botCharactersTable.rarity,
      imageUrl: botCharactersTable.imageUrl,
      isFavorite: botUserCharactersTable.isFavorite,
      caughtAt: botUserCharactersTable.caughtAt,
    })
    .from(botUserCharactersTable)
    .innerJoin(botCharactersTable, eq(botUserCharactersTable.characterId, botCharactersTable.id))
    .where(and(eq(botUserCharactersTable.id, charId), eq(botUserCharactersTable.userId, user.id)))
    .limit(1);

  const char = rows[0];
  if (!char) {
    await ctx.reply("❌ Character not found in your collection!\n\nUse /harem to see your collection.");
    return;
  }

  const caption =
    `${getRarityEmoji(char.rarity)} <b>${escapeHtml(char.name)}</b>\n\n` +
    `🎭 <b>Anime:</b> ${escapeHtml(char.anime)}\n` +
    `✨ <b>Rarity:</b> ${getRarityLabel(char.rarity)}\n` +
    `🆔 <b>Collection ID:</b> #${char.ucId}\n` +
    `📅 <b>Caught:</b> ${formatDate(char.caughtAt)}` +
    (char.isFavorite ? "\n⭐ <i>Favourite</i>" : "");

  await ctx.replyWithPhoto(char.imageUrl, { caption, parse_mode: "HTML" });
}
