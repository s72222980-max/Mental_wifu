import type { Context } from "telegraf";
import { Markup } from "telegraf";
import { getOrCreateUserWithStatus, PE } from "../utils";

const CATEGORIES = {
  bal: {
    text:
      `📜 <b>Bᴀʟ &amp; Pᴀʏ</b>\n\n` +
      `💰 <b>Balance Commands</b>\n` +
      `• /balance — Check your coins\n` +
      `• /pay &lt;amount&gt; @user — Send coins\n\n` +
      `🎁 <b>Bio Rewards</b>\n` +
      `• /daily — Claim daily coins\n` +
      `• /streak — Check daily streak`,
  },
  guess: {
    text:
      `📜 <b>Gᴜᴇss</b>\n\n` +
      `🎮 <b>Guess &amp; Snatch</b>\n` +
      `• When a wild character appears in group\n` +
      `• A hint shows first + last letter of each word\n` +
      `• Type the character's <b>exact full name</b>\n` +
      `• First to type it wins! ⚡ 90 second window\n\n` +
      `✅ Correct → +coins + character added to harem\n` +
      `🔥 Daily snatching → builds streak\n` +
      `🏆 Milestones → unlock achievements`,
  },
  harem: {
    text:
      `📜 <b>Hᴀʀᴇᴍ</b>\n\n` +
      `📚 <b>Collection Commands</b>\n` +
      `• /harem — View your collection\n` +
      `• /collection — Same as /harem\n` +
      `• /fav &lt;id&gt; — Set harem cover / favourite\n` +
      `• /gift &lt;id&gt; — Gift character (reply to user)\n` +
      `• /view &lt;id&gt; — View character details\n\n` +
      `<i>Use ◀ ▶ buttons to navigate, ⭐ to favourite</i>`,
  },
  streak: {
    text:
      `📜 <b>Sᴛʀᴇᴀᴋ</b>\n\n` +
      `🔥 <b>Streak System</b>\n` +
      `• /streak — Your daily snatch streak\n\n` +
      `🥉 Bronze (1+) | 🥈 Silver (3+) | 🥇 Gold (7+)\n` +
      `💎 Diamond (14+) | 🌟 Legendary (30+)\n\n` +
      `Miss 48h and your streak resets!`,
  },
  daily: {
    text:
      `📜 <b>Dᴀɪʟʏ</b>\n\n` +
      `🎁 <b>Daily Rewards</b>\n` +
      `• /daily — Claim daily coins &amp; stars\n` +
      `• /streak — Check your streak bonus tier\n\n` +
      `💰 Higher streak = bigger rewards!\n` +
      `🌟 Premium max: <b>750 coins/day</b>`,
  },
  drop: {
    text:
      `📜 <b>Dʀᴏᴘ</b>\n\n` +
      `🎲 <b>Drop System</b>\n` +
      `• /drop — Force spawn a character NOW\n\n` +
      `Only for: Group Admins ✅ &amp; Premium users ✅\n` +
      `❌ Cannot drop if one is already active`,
  },
  rankings: {
    text:
      `📜 <b>Rᴀɴᴋɪɴɢs</b>\n\n` +
      `🏆 <b>Rankings</b>\n` +
      `• /top — Top 10 by character count (global)\n` +
      `• /ctop — Top 10 in current group\n` +
      `• /mtop — Top 10 by coin balance\n` +
      `• /topstreak — Top 10 streak holders`,
  },
  check: {
    text:
      `📜 <b>Cʜᴇᴄᴋ</b>\n\n` +
      `🔍 <b>Character Check</b>\n` +
      `• /check @user — View user profile\n` +
      `• /check &lt;id&gt; — View character details\n\n` +
      `Shows name, anime, rarity, owner info`,
  },
  redeem: {
    text:
      `📜 <b>Rᴇᴅᴇᴇᴍ</b>\n\n` +
      `🎁 <b>Redeem Codes</b>\n` +
      `• /redeem &lt;code&gt; — Redeem a code for coins!\n\n` +
      `<b>Admin Only:</b>\n` +
      `• /gen &lt;CODE&gt; &lt;coins&gt; &lt;uses&gt; — Create code\n` +
      `• /codelist — View all active codes\n` +
      `• /delcode &lt;code&gt; — Delete a code`,
  },
  jackpot: {
    text:
      `📜 <b>Jᴀᴄᴋᴘᴏᴛ</b>\n\n` +
      `🎰 <b>Jackpot</b>\n` +
      `• /jackpot &lt;amount&gt; or /jk &lt;amount&gt;\n\n` +
      `Min bet: <b>10 coins</b> | Max bet: <b>10,000 coins</b>\n\n` +
      `💎💎💎 → 5× MEGA JACKPOT\n` +
      `⭐⭐⭐ → 3× JACKPOT\n` +
      `Any 3 same → 2× BIG WIN\n` +
      `Any 2 same → 1.5× Small Win\n` +
      `No match → Lose bet 💸`,
  },
  warn: {
    text:
      `📜 <b>Wᴀʀɴ</b>\n\n` +
      `⚠️ <b>Warning System (Group Admins)</b>\n` +
      `• /warn (reply) — Warn a user\n` +
      `• /warns (reply) — Check warning count\n` +
      `• /unwarn (reply) — Remove latest warn\n` +
      `• /resetwarns (reply) — Clear all warnings\n\n` +
      `Auto-mute after 3 warnings!`,
  },
  search: {
    text:
      `📜 <b>Sᴇᴀʀᴄʜ</b>\n\n` +
      `🔎 <b>Search Commands</b>\n` +
      `• /search &lt;query&gt; — Search by name or anime\n` +
      `• /cid &lt;name&gt; — Get character ID by name\n\n` +
      `• ✅ = you own it | ×2 = you have 2 copies\n` +
      `Example: <code>/cid Naruto</code>`,
  },
  sudo: {
    text:
      `📜 <b>Sᴜᴅᴏ</b>\n\n` +
      `👑 <b>Owner Commands</b>\n` +
      `• /addsudo (reply) — Grant sudo\n` +
      `• /removesudo (reply) — Remove sudo\n` +
      `• /sudolist — View all sudo users\n` +
      `• /sudo coins @user &lt;amount&gt; — Give coins\n` +
      `• /sudo ban @user — Ban user\n` +
      `• /sudo broadcast &lt;msg&gt; — Broadcast\n` +
      `• /sudo reseed — Reseed character DB\n` +
      `• /sudo stats — Bot statistics`,
  },
  admin: {
    text:
      `📜 <b>Aᴅᴍɪɴ Tᴏᴏʟs</b>\n\n` +
      `👑 <b>Owner Admin Tools</b>\n\n` +
      `💰 Coins:\n` +
      `• /sudo coins @user &lt;amount&gt; — Give coins\n\n` +
      `🎁 Characters:\n` +
      `• /cid &lt;name&gt; — Find character ID\n\n` +
      `👤 Users:\n` +
      `• /check @user — User info\n` +
      `• /sudo ban @user — Ban\n` +
      `• /sudo unban @user — Unban\n\n` +
      `🎁 User Tools:\n` +
      `• /gift &lt;id&gt; — Gift character (reply)\n` +
      `• /pay &lt;amount&gt; @user — Gift coins`,
  },
  profile: {
    text:
      `📜 <b>Pʀᴏꜰɪʟᴇ</b>\n\n` +
      `📊 <b>Profile</b>\n` +
      `• /profile or /me — View your profile card\n` +
      `• /check @user — View another user's profile\n\n` +
      `Shows rank, character count, progress,\n` +
      `rarity distribution, streak &amp; premium status.`,
  },
  spawn: {
    text:
      `📜 <b>Sᴘᴀᴡɴ Tɪᴍᴇ</b>\n\n` +
      `⏱ <b>Spawn Time Control</b>\n` +
      `• /spawntime — View current settings\n` +
      `• /setmsgspawn &lt;msgs&gt; — Set spawn interval\n` +
      `• /setspawntime &lt;mins&gt; — Time-based spawn\n\n` +
      `Group Admins: 5–500 messages\n` +
      `Default: every 20 messages`,
  },
  panel: {
    text:
      `📜 <b>Aᴅᴍɪɴ Pᴀɴᴇʟ</b>\n\n` +
      `👑 <b>Inline Admin Panel</b>\n` +
      `• /panel — Open the Admin Panel\n\n` +
      `Full inline panel with buttons to:\n` +
      `• View spawn settings\n` +
      `• Manage group configuration\n` +
      `• View bot stats\n\n` +
      `Owner and sudo admins only!`,
  },
  premium: {
    text:
      `📜 <b>Pʀᴇᴍɪᴜᴍ</b>\n\n` +
      `👑 <b>Premium Membership</b>\n\n` +
      `📋 Info &amp; Purchase:\n` +
      `• /premium — Check your status\n` +
      `• /buypremium — View pricing &amp; buy\n\n` +
      `✨ <b>Premium Perks:</b>\n` +
      `🎁 1 peak rarity character/day\n` +
      `⭐ 10 stars + 2,500 coins/day\n` +
      `👑 Premium badge everywhere\n` +
      `🔍 Full name hint advantage\n` +
      `🛡️ Steal immunity!\n\n` +
      `💰 <b>Pricing:</b>\n` +
      `🌟 70₹ — 7 Days\n` +
      `💎 140₹ — 1 Month\n` +
      `👑 240₹ — 2 Months\n` +
      `🔮 340₹ — 3 Months\n\n` +
      `Contact: @zctol or @urlordbaby`,
  },
} as const;

type CategoryKey = keyof typeof CATEGORIES;

function formatUptime(): string {
  const s = Math.floor(process.uptime());
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${h}h ${m}m ${sec}s`;
}

function getWelcomeText(): string {
  return (
    `${PE.party} <b>Welcome to Snatch Your Character!</b>\n\n` +
    `${PE.sword} Snatch anime characters, build your harem,\n` +
    `${PE.coin} earn coins, and dominate the leaderboards!\n\n` +
    `${PE.rocket} Uptime: ${formatUptime()}\n\n` +
    `<blockquote>Use /help to see all commands!</blockquote>`
  );
}

function mainKeyboard() {
  const sgLink = process.env.SUPPORT_GROUP_LINK ?? "https://t.me/+tm6dr4ZEyZE5ZjNl";
  const ucLink = process.env.UPDATES_CHANNEL_LINK ?? "https://t.me/ABOUTxYUTAA";
  const botUsername = process.env.BOT_USERNAME ?? "Mental_wify_bot";

  return Markup.inlineKeyboard([
    [
      Markup.button.url("➕ Add to Group", `https://t.me/${botUsername}?startgroup=start`),
      Markup.button.url("💬 Support", sgLink),
    ],
    [
      Markup.button.url("📢 Updates", ucLink),
      Markup.button.callback("❓ Help", "help_home"),
    ],
  ]);
}

const HELP_MAIN_TEXT = `📋 <b>Waifu Snatch Bot — Help Menu</b>\n\n<b>Choose a category:</b>`;

function helpKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback("📜 Bᴀʟ & Pᴀʏ",   "help_bal"),    Markup.button.callback("🎯 Gᴜᴇss",       "help_guess")],
    [Markup.button.callback("🌸 Hᴀʀᴇᴍ",         "help_harem"),  Markup.button.callback("🔥 Sᴛʀᴇᴀᴋ",      "help_streak")],
    [Markup.button.callback("🎁 Dᴀɪʟʏ",         "help_daily"),  Markup.button.callback("⚡ Dʀᴏᴘ",         "help_drop")],
    [Markup.button.callback("🏆 Rᴀɴᴋɪɴɢs",     "help_rankings"),Markup.button.callback("🔍 Cʜᴇᴄᴋ",      "help_check")],
    [Markup.button.callback("🎟 Rᴇᴅᴇᴇᴍ",       "help_redeem"), Markup.button.callback("🎰 Jᴀᴄᴋᴘᴏᴛ",     "help_jackpot")],
    [Markup.button.callback("⚠️ Wᴀʀɴ",          "help_warn"),   Markup.button.callback("🔎 Sᴇᴀʀᴄʜ",      "help_search")],
    [Markup.button.callback("👑 Sᴜᴅᴏ",          "help_sudo"),   Markup.button.callback("🛠 Aᴅᴍɪɴ",       "help_admin")],
    [Markup.button.callback("👤 Pʀᴏꜰɪʟᴇ",      "help_profile"),Markup.button.callback("⏱ Sᴘᴀᴡɴ",       "help_spawn")],
    [Markup.button.callback("⚙️ Pᴀɴᴇʟ",         "help_panel"),  Markup.button.callback("🌟 Pʀᴇᴍɪᴜᴍ",     "help_premium")],
  ]);
}

function homeKeyboard() {
  return Markup.inlineKeyboard([[Markup.button.callback("🏠 Home", "help_home")]]);
}

function firstTimeKeyboard() {
  const sgLink = process.env.SUPPORT_GROUP_LINK ?? "https://t.me/+tm6dr4ZEyZE5ZjNl";
  const ucLink = process.env.UPDATES_CHANNEL_LINK ?? "https://t.me/ABOUTxYUTAA";
  return Markup.inlineKeyboard([
    [
      Markup.button.url("👥 Support Group", sgLink),
      Markup.button.url("📢 Updates Channel", ucLink),
    ],
  ]);
}

export async function handleStart(ctx: Context): Promise<void> {
  if (!ctx.from) return;
  const { isNew } = await getOrCreateUserWithStatus(ctx.from);

  const welcomeText = getWelcomeText();
  const keyboard = mainKeyboard();

  try {
    const photos = await ctx.telegram.getUserProfilePhotos(ctx.botInfo!.id, 0, 1);
    const fileId = photos.photos[0]?.[0]?.file_id;
    if (fileId) {
      await ctx.replyWithPhoto(fileId, {
        caption: welcomeText,
        parse_mode: "HTML",
        reply_markup: keyboard.reply_markup,
      });
    } else {
      await ctx.reply(welcomeText, { parse_mode: "HTML", reply_markup: keyboard.reply_markup });
    }
  } catch {
    await ctx.reply(welcomeText, { parse_mode: "HTML", reply_markup: keyboard.reply_markup });
  }

  if (isNew) {
    await ctx.reply(
      `${PE.cherry} <b>Your harem is empty!</b>\n\n` +
      `Join a group with this bot and catch characters when they appear!\n\n` +
      `${PE.lightning} Characters spawn automatically — use /name to snatch them!\n\n` +
      `<blockquote>Join our community to stay updated!</blockquote>`,
      {
        parse_mode: "HTML",
        reply_markup: firstTimeKeyboard().reply_markup,
      },
    );
  }
}

export async function handleHelp(ctx: Context): Promise<void> {
  await ctx.reply(HELP_MAIN_TEXT, { parse_mode: "HTML", reply_markup: helpKeyboard().reply_markup });
}

export async function handleHelpCallback(ctx: Context & { match: RegExpMatchArray }): Promise<void> {
  const key = ctx.match[1] as string;

  if (key === "home") {
    await ctx.answerCbQuery();
    await ctx.reply(HELP_MAIN_TEXT, {
      parse_mode: "HTML",
      reply_markup: helpKeyboard().reply_markup,
    });
    return;
  }

  const cat = CATEGORIES[key as CategoryKey];
  if (!cat) { await ctx.answerCbQuery(); return; }

  try {
    await ctx.editMessageText(cat.text, {
      parse_mode: "HTML",
      reply_markup: homeKeyboard().reply_markup,
    });
  } catch {}
  await ctx.answerCbQuery();
}
