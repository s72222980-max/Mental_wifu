import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botWarningsTable } from "@workspace/db";
import { eq, and, desc, count } from "drizzle-orm";
import { isGroupAdmin, getUserByUsername, escapeHtml, formatDate } from "../utils";

async function getTargetFromCtx(ctx: Context): Promise<{ telegramId: string; name: string } | null> {
  if (!ctx.message) return null;
  const replyTo = "reply_to_message" in ctx.message ? ctx.message.reply_to_message : null;
  if (replyTo && replyTo.from && !replyTo.from.is_bot) {
    return { telegramId: String(replyTo.from.id), name: replyTo.from.first_name };
  }
  const text = "text" in ctx.message ? ctx.message.text : "";
  const mention = text.trim().split(/\s+/)[1];
  if (mention?.startsWith("@")) {
    const found = await getUserByUsername(mention.slice(1));
    if (found) return { telegramId: found.telegramId, name: found.firstName };
  }
  return null;
}

export async function handleWarn(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.chat || !ctx.message) return;
  if (ctx.chat.type !== "group" && ctx.chat.type !== "supergroup") {
    await ctx.reply("⚠️ /warn only works in groups!");
    return;
  }
  if (!(await isGroupAdmin(ctx))) {
    await ctx.reply("❌ Only group admins can warn users!");
    return;
  }

  const target = await getTargetFromCtx(ctx);
  if (!target) {
    await ctx.reply(
      "❌ <b>Warn Usage:</b>\nReply to a message: <code>/warn [reason]</code>\nOr: <code>/warn @username [reason]</code>",
      { parse_mode: "HTML" },
    );
    return;
  }

  if (String(ctx.from.id) === target.telegramId) { await ctx.reply("❌ Can't warn yourself!"); return; }

  const text = "text" in ctx.message ? ctx.message.text : "";
  const replyTo = "reply_to_message" in ctx.message ? ctx.message.reply_to_message : null;
  const parts = text.trim().split(/\s+/).slice(1);
  const reason = replyTo ? parts.join(" ") || "No reason given" : parts.slice(1).join(" ") || "No reason given";

  const groupId = String(ctx.chat.id);

  await db.insert(botWarningsTable).values({
    groupId,
    telegramId: target.telegramId,
    reason,
    warnedBy: String(ctx.from.id),
  });

  const warnRows = await db.select({ cnt: count() }).from(botWarningsTable)
    .where(and(eq(botWarningsTable.groupId, groupId), eq(botWarningsTable.telegramId, target.telegramId)));
  const totalWarns = Number(warnRows[0]?.cnt ?? 1);

  await ctx.reply(
    `⚠️ <b>${escapeHtml(target.name)}</b> has been warned!\n\n` +
      `📝 <b>Reason:</b> ${escapeHtml(reason)}\n` +
      `📊 <b>Total Warnings:</b> ${totalWarns}`,
    { parse_mode: "HTML" },
  );
}

export async function handleWarns(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.chat) return;

  let targetTelegramId = String(ctx.from.id);
  let targetName = ctx.from.first_name;

  if (ctx.message) {
    const text = "text" in ctx.message ? ctx.message.text : "";
    const mention = text.trim().split(/\s+/)[1];
    const replyTo = "reply_to_message" in ctx.message ? ctx.message.reply_to_message : null;
    if (replyTo?.from && !replyTo.from.is_bot) {
      targetTelegramId = String(replyTo.from.id);
      targetName = replyTo.from.first_name;
    } else if (mention?.startsWith("@")) {
      const found = await getUserByUsername(mention.slice(1));
      if (found) { targetTelegramId = found.telegramId; targetName = found.firstName; }
    }
  }

  if (ctx.chat.type !== "group" && ctx.chat.type !== "supergroup") {
    await ctx.reply("⚠️ /warns only works in groups!");
    return;
  }

  const groupId = String(ctx.chat.id);
  const warnings = await db
    .select()
    .from(botWarningsTable)
    .where(and(eq(botWarningsTable.groupId, groupId), eq(botWarningsTable.telegramId, targetTelegramId)))
    .orderBy(desc(botWarningsTable.createdAt))
    .limit(10);

  if (warnings.length === 0) {
    await ctx.reply(`✅ <b>${escapeHtml(targetName)}</b> has no warnings in this group!`, { parse_mode: "HTML" });
    return;
  }

  const lines = warnings.map((w, i) =>
    `${i + 1}. <b>${escapeHtml(w.reason ?? "No reason")}</b>\n   <i>${formatDate(w.createdAt)}</i>`,
  );

  await ctx.reply(
    `⚠️ <b>Warnings for ${escapeHtml(targetName)}</b> (${warnings.length})\n\n` + lines.join("\n\n"),
    { parse_mode: "HTML" },
  );
}

export async function handleUnwarn(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.chat) return;
  if (!(await isGroupAdmin(ctx))) { await ctx.reply("❌ Only group admins can remove warnings!"); return; }
  if (ctx.chat.type !== "group" && ctx.chat.type !== "supergroup") { await ctx.reply("⚠️ Groups only!"); return; }

  const target = await getTargetFromCtx(ctx);
  if (!target) { await ctx.reply("❌ Reply to user or @mention them!"); return; }

  const groupId = String(ctx.chat.id);
  const latest = await db
    .select()
    .from(botWarningsTable)
    .where(and(eq(botWarningsTable.groupId, groupId), eq(botWarningsTable.telegramId, target.telegramId)))
    .orderBy(desc(botWarningsTable.createdAt))
    .limit(1);

  if (!latest[0]) {
    await ctx.reply(`✅ <b>${escapeHtml(target.name)}</b> has no warnings to remove!`, { parse_mode: "HTML" });
    return;
  }

  await db.delete(botWarningsTable).where(eq(botWarningsTable.id, latest[0].id));
  await ctx.reply(`✅ Latest warning removed from <b>${escapeHtml(target.name)}</b>!`, { parse_mode: "HTML" });
}

export async function handleResetWarns(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.chat) return;
  if (!(await isGroupAdmin(ctx))) { await ctx.reply("❌ Only group admins can reset warnings!"); return; }
  if (ctx.chat.type !== "group" && ctx.chat.type !== "supergroup") { await ctx.reply("⚠️ Groups only!"); return; }

  const target = await getTargetFromCtx(ctx);
  if (!target) { await ctx.reply("❌ Reply to user or @mention them!"); return; }

  await db.delete(botWarningsTable).where(
    and(eq(botWarningsTable.groupId, String(ctx.chat.id)), eq(botWarningsTable.telegramId, target.telegramId)),
  );
  await ctx.reply(`✅ All warnings cleared for <b>${escapeHtml(target.name)}</b>!`, { parse_mode: "HTML" });
}
