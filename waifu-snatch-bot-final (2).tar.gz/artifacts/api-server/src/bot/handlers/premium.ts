import type { Context } from "telegraf";
import { Markup } from "telegraf";
import { db } from "@workspace/db";
import { botPremiumUsersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { checkPremium, isOwner, escapeHtml, formatDate, PE } from "../utils";

const PRICING_TEXT =
  `${PE.coin} <b>Premium Pricing:</b>\n` +
  `${PE.star} <b>70₹</b> — 7 Days\n` +
  `${PE.gem} <b>140₹</b> — 1 Month\n` +
  `${PE.crown} <b>240₹</b> — 2 Months\n` +
  `🔮 <b>340₹</b> — 3 Months`;

const PERKS_TEXT =
  `${PE.sparkles} <b>Premium Perks:</b>\n` +
  `${PE.gift} 1 free peak rarity character/day\n` +
  `${PE.star} 10 stars + 2,500 coins daily\n` +
  `${PE.crown} Premium badge displayed everywhere\n` +
  `🔍 Full name hint while guessing\n` +
  `🛡️ Steal immunity (no one can rob you!)\n` +
  `${PE.lightning} Shop items last 72h instead of 24h\n` +
  `${PE.fire} Weekly streak bonus: +50 stars after 7 days straight!`;

const CONTACT_TEXT = `Contact: @zctol (primary) or @urlordbaby (backup)`;

export async function handlePremium(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.message) return;

  const text = "text" in ctx.message ? ctx.message.text : "";
  const parts = text.trim().split(/\s+/);

  if (parts.length >= 3 && isOwner(String(ctx.from.id))) {
    await grantPremiumOwner(ctx, parts[1]!, parts[2]!);
    return;
  }

  const isPremium = await checkPremium(String(ctx.from.id));

  if (isPremium) {
    const rows = await db.select().from(botPremiumUsersTable).where(eq(botPremiumUsersTable.telegramId, String(ctx.from.id))).limit(1);
    const prem = rows[0];
    const expiry = prem?.expiresAt ? `Expires: <b>${formatDate(prem.expiresAt)}</b>` : `Status: <b>Lifetime ♾️</b>`;

    await ctx.reply(
      `🌟 <b>${escapeHtml(ctx.from.first_name)}, you have Premium!</b>\n\n${expiry}\n\n${PERKS_TEXT}\n\n<blockquote>Thank you for supporting the bot! 💖</blockquote>`,
      { parse_mode: "HTML" },
    );
  } else {
    await ctx.reply(
      `🔒 <b>No Premium Found</b>\n\nYou don't have an active premium subscription.\n\n${PERKS_TEXT}\n\n${PRICING_TEXT}\n\n${CONTACT_TEXT}`,
      {
        parse_mode: "HTML",
        reply_markup: Markup.inlineKeyboard([
          [Markup.button.callback("💎 Buy Premium", "buy_premium_info")],
        ]).reply_markup,
      },
    );
  }
}

export async function handleBuyPremium(ctx: Context): Promise<void> {
  const caption =
    `👑 <b>Buy Premium</b>\n\n${PERKS_TEXT}\n\n${PRICING_TEXT}\n\n` +
    `<b>How to pay (UPI):</b>\n` +
    `1️⃣ Pay the amount for your desired plan\n` +
    `2️⃣ Take a screenshot of payment confirmation\n` +
    `3️⃣ Send screenshot + your Telegram ID to @zctol\n\n` +
    `📱 Your Telegram ID: <code>${ctx.from?.id ?? "?"}</code>\n\n` +
    `<blockquote>${CONTACT_TEXT}</blockquote>`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.url("💬 Contact @zctol", "https://t.me/zctol")],
  ]);

  await ctx.reply(caption, { parse_mode: "HTML", reply_markup: keyboard.reply_markup });
}

export async function handleBuyPremiumCallback(ctx: Context): Promise<void> {
  await ctx.answerCbQuery();
  await handleBuyPremium(ctx);
}

async function grantPremiumOwner(ctx: Context, daysStr: string, targetId: string): Promise<void> {
  const days = parseInt(daysStr, 10);
  if (isNaN(days) || days <= 0) {
    await ctx.reply(`❌ Invalid days!\n\n<b>Usage:</b> <code>/premium [days] [telegram_id]</code>`, { parse_mode: "HTML" });
    return;
  }

  const telegramId = targetId.replace("@", "");
  const expiresAt = new Date(Date.now() + days * 24 * 60 * 60 * 1000);

  const existing = await db.select().from(botPremiumUsersTable).where(eq(botPremiumUsersTable.telegramId, telegramId)).limit(1);

  if (existing.length > 0) {
    await db.update(botPremiumUsersTable).set({ expiresAt, grantedBy: String(ctx.from!.id) }).where(eq(botPremiumUsersTable.telegramId, telegramId));
  } else {
    await db.insert(botPremiumUsersTable).values({ telegramId, grantedBy: String(ctx.from!.id), expiresAt });
  }

  await ctx.reply(
    `✅ <b>Premium Granted!</b>\n\nUser ID: <code>${escapeHtml(telegramId)}</code>\nDuration: <b>${days} days</b>\nExpires: <b>${formatDate(expiresAt)}</b>`,
    { parse_mode: "HTML" },
  );

  try {
    await ctx.telegram.sendMessage(
      telegramId,
      `🌟 <b>Premium Activated!</b>\n\nYour premium is active for <b>${days} days</b>!\nExpires: <b>${formatDate(expiresAt)}</b>\n\n${PERKS_TEXT}\n\n<i>Thank you for supporting the bot! 💖</i>`,
      { parse_mode: "HTML" },
    );
  } catch {}
}
