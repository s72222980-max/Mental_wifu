import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botUsersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getOrCreateUser, getUserByTelegramId, getUserByUsername, checkPremium, escapeHtml, PE } from "../utils";

export async function handleBal(ctx: Context): Promise<void> {
  if (!ctx.from) return;
  const user = await getOrCreateUser(ctx.from);
  const isPremium = await checkPremium(String(ctx.from.id));
  const badge = isPremium ? ` ${PE.crown}` : "";

  await ctx.reply(
    `${PE.coin} <b>${escapeHtml(ctx.from.first_name)}'s Balance${badge}</b>\n\n` +
      `Coins: <b>${user.coins.toLocaleString()} ${PE.coin}</b>\n\n` +
      `<blockquote>Earn coins by catching characters, /daily rewards, or /jackpot!</blockquote>`,
    { parse_mode: "HTML" },
  );
}

export async function handlePay(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.message) return;

  const text = "text" in ctx.message ? ctx.message.text : "";
  const parts = text.trim().split(/\s+/).slice(1);
  const replyTo = "reply_to_message" in ctx.message ? ctx.message.reply_to_message : null;

  let targetTelegramId: string | null = null;
  let amountStr: string | undefined;

  if (replyTo && replyTo.from && !replyTo.from.is_bot) {
    targetTelegramId = String(replyTo.from.id);
    amountStr = parts[0];
  } else if (parts[0]?.startsWith("@")) {
    const found = await getUserByUsername(parts[0].slice(1));
    if (!found) {
      await ctx.reply(`❌ User <b>${escapeHtml(parts[0])}</b> not found! Ask them to /start the bot first.`, { parse_mode: "HTML" });
      return;
    }
    targetTelegramId = found.telegramId;
    amountStr = parts[1];
  } else {
    await ctx.reply(
      `💸 <b>Pay Usage:</b>\n\n` +
        `Reply to user: <code>/pay [amount]</code>\n` +
        `Or: <code>/pay @username [amount]</code>`,
      { parse_mode: "HTML" },
    );
    return;
  }

  const amount = parseInt(amountStr ?? "");
  if (isNaN(amount) || amount <= 0) { await ctx.reply("❌ Invalid amount! Must be a positive number."); return; }
  if (amount > 1_000_000) { await ctx.reply("❌ Max transfer: 1,000,000 coins per transaction!"); return; }
  if (String(ctx.from.id) === targetTelegramId) { await ctx.reply("❌ You can't pay yourself!"); return; }

  const sender = await getOrCreateUser(ctx.from);
  if (sender.coins < amount) {
    await ctx.reply(`❌ Insufficient balance!\nYou have <b>${sender.coins.toLocaleString()} coins</b>, need <b>${amount.toLocaleString()}</b>.`, { parse_mode: "HTML" });
    return;
  }

  const receiver = await getUserByTelegramId(targetTelegramId!);
  if (!receiver) { await ctx.reply("❌ Receiver not found! Ask them to /start the bot."); return; }

  await db.update(botUsersTable).set({ coins: sender.coins - amount }).where(eq(botUsersTable.id, sender.id));
  await db.update(botUsersTable).set({ coins: receiver.coins + amount }).where(eq(botUsersTable.id, receiver.id));

  await ctx.reply(
    `💸 <b>Payment Sent!</b>\n\n` +
      `👤 From: <b>${escapeHtml(sender.firstName)}</b>\n` +
      `👤 To: <b>${escapeHtml(receiver.firstName)}</b>\n` +
      `💰 Amount: <b>${amount.toLocaleString()} coins</b>\n\n` +
      `Your new balance: <b>${(sender.coins - amount).toLocaleString()} coins</b>`,
    { parse_mode: "HTML" },
  );
}
