import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botUsersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getOrCreateUser } from "../utils";

const SLOTS = ["🍒", "🍋", "🍊", "🍇", "⭐", "💎"];
const MIN_BET = 10;
const MAX_BET = 10_000;

function spin(): [string, string, string] {
  return [
    SLOTS[Math.floor(Math.random() * SLOTS.length)]!,
    SLOTS[Math.floor(Math.random() * SLOTS.length)]!,
    SLOTS[Math.floor(Math.random() * SLOTS.length)]!,
  ];
}

interface Result { multiplier: number; label: string }

function calcResult(s: [string, string, string]): Result {
  if (s[0] === s[1] && s[1] === s[2]) {
    if (s[0] === "💎") return { multiplier: 5, label: "🎰 MEGA JACKPOT! 5x!" };
    if (s[0] === "⭐") return { multiplier: 3, label: "🎊 JACKPOT! 3x!" };
    return { multiplier: 2, label: "🎉 BIG WIN! 2x!" };
  }
  if (s[0] === s[1] || s[1] === s[2] || s[0] === s[2]) {
    return { multiplier: 1.5, label: "✨ Small Win! 1.5x" };
  }
  return { multiplier: 0, label: "💸 Better luck next time!" };
}

export async function handleJackpot(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.message) return;

  const text = "text" in ctx.message ? ctx.message.text : "";
  const betStr = text.trim().split(/\s+/)[1];

  if (!betStr) {
    await ctx.reply(
      `🎰 <b>Jackpot Machine!</b>\n\n` +
        `<code>/jackpot [amount]</code>\n\n` +
        `Min bet: <b>${MIN_BET}</b> | Max bet: <b>${MAX_BET.toLocaleString()}</b>\n\n` +
        `<b>Payouts:</b>\n` +
        `💎💎💎 → 5x MEGA JACKPOT!\n` +
        `⭐⭐⭐ → 3x JACKPOT!\n` +
        `Any 3 same → 2x BIG WIN\n` +
        `Any 2 same → 1.5x Small Win\n` +
        `No match → 0x (lose bet)`,
      { parse_mode: "HTML" },
    );
    return;
  }

  const bet = parseInt(betStr);
  if (isNaN(bet) || bet < MIN_BET) { await ctx.reply(`❌ Minimum bet is <b>${MIN_BET} coins</b>!`, { parse_mode: "HTML" }); return; }
  if (bet > MAX_BET) { await ctx.reply(`❌ Maximum bet is <b>${MAX_BET.toLocaleString()} coins</b>!`, { parse_mode: "HTML" }); return; }

  const user = await getOrCreateUser(ctx.from);
  if (user.coins < bet) {
    await ctx.reply(`❌ Insufficient balance! You have <b>${user.coins.toLocaleString()} coins</b>.`, { parse_mode: "HTML" });
    return;
  }

  const slots = spin();
  const { multiplier, label } = calcResult(slots);
  const winnings = Math.floor(bet * multiplier);
  const change = winnings - bet;
  const newBalance = user.coins + change;

  await db.update(botUsersTable).set({ coins: newBalance }).where(eq(botUsersTable.id, user.id));

  const changeStr = change >= 0 ? `+${change.toLocaleString()}` : `${change.toLocaleString()}`;
  const resultLine = change >= 0
    ? `💰 <b>Won: ${winnings.toLocaleString()} coins</b> (<b>${changeStr}</b>)`
    : `💸 <b>Lost: ${bet.toLocaleString()} coins</b>`;

  await ctx.reply(
    `🎰 <b>JACKPOT MACHINE</b>\n` +
      `━━━━━━━━━━━━━━━━━\n` +
      `  ${slots[0]} | ${slots[1]} | ${slots[2]}  \n` +
      `━━━━━━━━━━━━━━━━━\n\n` +
      `${label}\n` +
      `${resultLine}\n` +
      `💼 Balance: <b>${newBalance.toLocaleString()} coins</b>`,
    { parse_mode: "HTML" },
  );
}
