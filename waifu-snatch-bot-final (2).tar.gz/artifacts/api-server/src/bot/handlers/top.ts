import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botUsersTable } from "@workspace/db";
import { desc } from "drizzle-orm";
import { escapeHtml } from "../utils";

const MEDALS = ["🥇", "🥈", "🥉"];

export async function handleTop(ctx: Context): Promise<void> {
  const top = await db
    .select({
      firstName: botUsersTable.firstName,
      username: botUsersTable.username,
      totalCaught: botUsersTable.totalCaught,
      coins: botUsersTable.coins,
    })
    .from(botUsersTable)
    .orderBy(desc(botUsersTable.totalCaught))
    .limit(10);

  if (top.length === 0) {
    await ctx.reply("🏆 No hunters yet! Be the first to catch a character in a group!");
    return;
  }

  const lines = top.map((u, i) => {
    const medal = MEDALS[i] ?? `${i + 1}.`;
    const name = u.username ? `@${escapeHtml(u.username)}` : escapeHtml(u.firstName);
    return `${medal} <b>${name}</b> — ${u.totalCaught} caught | 💰 ${u.coins}`;
  });

  const text =
    `🏆 <b>Top Waifu Hunters</b>\n\n` + lines.join("\n") + `\n\n<blockquote>Add me to a group and start catching characters!</blockquote>`;

  await ctx.reply(text, { parse_mode: "HTML" });
}
