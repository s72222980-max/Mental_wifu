import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botGroupSettingsTable, botGroupStatsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { isGroupAdmin, isSudoAdmin, escapeHtml } from "../utils";

export async function handleSpawnTime(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.chat) return;
  if (ctx.chat.type !== "group" && ctx.chat.type !== "supergroup") {
    await ctx.reply("⚠️ This command only works in groups!");
    return;
  }

  const groupId = String(ctx.chat.id);
  const rows = await db.select().from(botGroupSettingsTable).where(eq(botGroupSettingsTable.groupId, groupId)).limit(1);
  const settings = rows[0];
  const statsRows = await db.select().from(botGroupStatsTable).where(eq(botGroupStatsTable.groupId, groupId)).limit(1);
  const stats = statsRows[0];

  const msgSpawn = settings?.msgSpawnCount ?? 20;
  const timeMins = settings?.spawnIntervalMins ?? null;

  await ctx.reply(
    `⏱ <b>Spawn Settings</b>\n\n` +
      `📨 <b>Message-based:</b> Every <b>${msgSpawn} messages</b>\n` +
      `⏰ <b>Time-based:</b> ${timeMins ? `Every <b>${timeMins} minutes</b>` : "Disabled"}\n` +
      `📊 <b>Current message count:</b> ${stats?.messageCount ?? 0}\n\n` +
      `<b>Commands:</b>\n` +
      `• /setmsgspawn &lt;5-500&gt; — Change message interval\n` +
      `• /setspawntime &lt;mins&gt; — Set time interval (0 to disable)\n\n` +
      `<i>Group admins and sudo users only.</i>`,
    { parse_mode: "HTML" },
  );
}

export async function handleSetMsgSpawn(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.chat || !ctx.message) return;
  if (ctx.chat.type !== "group" && ctx.chat.type !== "supergroup") { await ctx.reply("⚠️ Groups only!"); return; }

  const isAdmin = await isGroupAdmin(ctx);
  const isSudo = await isSudoAdmin(String(ctx.from.id));

  if (!isAdmin && !isSudo) {
    await ctx.reply("❌ Only group admins or sudo users can change spawn settings!");
    return;
  }

  const text = "text" in ctx.message ? ctx.message.text : "";
  const countStr = text.trim().split(/\s+/)[1];
  const count = parseInt(countStr ?? "");

  if (isNaN(count) || count < 5 || count > 500) {
    await ctx.reply("❌ Invalid value! Use a number between 5 and 500.");
    return;
  }

  const groupId = String(ctx.chat.id);
  await db.insert(botGroupSettingsTable).values({ groupId, msgSpawnCount: count }).onConflictDoUpdate({
    target: botGroupSettingsTable.groupId,
    set: { msgSpawnCount: count, updatedAt: new Date() },
  });

  await ctx.reply(`✅ Spawn interval set to <b>${count} messages</b>!`, { parse_mode: "HTML" });
}

export async function handleSetSpawnTime(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.chat || !ctx.message) return;
  if (ctx.chat.type !== "group" && ctx.chat.type !== "supergroup") { await ctx.reply("⚠️ Groups only!"); return; }

  const isAdmin = await isGroupAdmin(ctx);
  const isSudo = await isSudoAdmin(String(ctx.from.id));

  if (!isAdmin && !isSudo) {
    await ctx.reply("❌ Only group admins or sudo users can change spawn settings!");
    return;
  }

  const text = "text" in ctx.message ? ctx.message.text : "";
  const minsStr = text.trim().split(/\s+/)[1];
  const mins = parseInt(minsStr ?? "");

  if (isNaN(mins) || mins < 0) { await ctx.reply("❌ Invalid value! Use 0 to disable, or minutes (e.g. 30)."); return; }

  const groupId = String(ctx.chat.id);
  await db.insert(botGroupSettingsTable)
    .values({ groupId, spawnIntervalMins: mins === 0 ? null : mins })
    .onConflictDoUpdate({
      target: botGroupSettingsTable.groupId,
      set: { spawnIntervalMins: mins === 0 ? null : mins, updatedAt: new Date() },
    });

  await ctx.reply(
    mins === 0
      ? `✅ Time-based spawning <b>disabled</b>!`
      : `✅ Spawn time interval set to <b>${mins} minutes</b>!`,
    { parse_mode: "HTML" },
  );
}
