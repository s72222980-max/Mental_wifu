import type { Context } from "telegraf";
import { getOrCreateUser, PE } from "../utils";

const BASE_COINS = 100;
const STREAK_BONUS = 50;
const MAX_BONUS = 500;

function calcReward(streak: number): number {
  return Math.min(BASE_COINS + streak * STREAK_BONUS, MAX_BONUS);
}

function buildStreakBar(streak: number): string {
  const maxBar = 7;
  const filled = Math.min(streak % 7 || (streak > 0 ? 7 : 0), maxBar);
  return "🟨".repeat(filled) + "⬜".repeat(maxBar - filled);
}

function getTier(streak: number): string {
  if (streak >= 30) return `${PE.legendary} Legendary`;
  if (streak >= 14) return `${PE.gem} Diamond`;
  if (streak >= 7)  return "🥇 Gold";
  if (streak >= 3)  return "🥈 Silver";
  if (streak >= 1)  return "🥉 Bronze";
  return "None";
}

export async function handleStreak(ctx: Context): Promise<void> {
  if (!ctx.from) return;
  const user = await getOrCreateUser(ctx.from);

  const now = Date.now();
  const lastMs = user.lastDailyAt ? user.lastDailyAt.getTime() : 0;
  const elapsed = now - lastMs;
  const cooldown = 24 * 60 * 60 * 1000;
  const canClaim = elapsed >= cooldown;

  const nextReward = calcReward(user.streakDays);
  const streakBar = buildStreakBar(user.streakDays);

  let timeMsg = "";
  if (!canClaim && lastMs > 0) {
    const remaining = cooldown - elapsed;
    const h = Math.floor(remaining / 3_600_000);
    const m = Math.floor((remaining % 3_600_000) / 60_000);
    timeMsg = `\n⏳ Next claim in: <b>${h}h ${m}m</b>`;
  }

  await ctx.reply(
    `${PE.fire} <b>${user.firstName}'s Streak</b>\n\n` +
      `${streakBar}\n\n` +
      `🏅 <b>Tier:</b> ${getTier(user.streakDays)}\n` +
      `🔢 <b>Days:</b> ${user.streakDays}\n` +
      `${PE.coin} <b>Next Reward:</b> ${nextReward} coins\n` +
      (canClaim ? `\n${PE.check} <b>Ready to claim!</b> Use /daily` : timeMsg) +
      `\n\n<blockquote>🥉 Bronze 1+ | 🥈 Silver 3+ | 🥇 Gold 7+ | ${PE.gem} Diamond 14+ | ${PE.legendary} Legendary 30+</blockquote>`,
    { parse_mode: "HTML" },
  );
}
