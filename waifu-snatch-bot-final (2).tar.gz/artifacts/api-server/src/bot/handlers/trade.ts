import type { Context } from "telegraf";
import { Markup } from "telegraf";
import { db } from "@workspace/db";
import { botTradesTable, botUserCharactersTable, botCharactersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { getOrCreateUser, getUserByTelegramId, getUserByUsername, getRarityEmoji, escapeHtml } from "../utils";

async function getCharWithOwner(userCharId: number, ownerId: number) {
  const rows = await db
    .select({
      ucId: botUserCharactersTable.id,
      userId: botUserCharactersTable.userId,
      name: botCharactersTable.name,
      anime: botCharactersTable.anime,
      rarity: botCharactersTable.rarity,
    })
    .from(botUserCharactersTable)
    .innerJoin(botCharactersTable, eq(botUserCharactersTable.characterId, botCharactersTable.id))
    .where(and(eq(botUserCharactersTable.id, userCharId), eq(botUserCharactersTable.userId, ownerId)))
    .limit(1);
  return rows[0] ?? null;
}

export async function handleTrade(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.message) return;

  const text = "text" in ctx.message ? ctx.message.text : "";
  const parts = text.trim().split(/\s+/).slice(1);
  const replyTo = "reply_to_message" in ctx.message ? ctx.message.reply_to_message : null;

  let targetTelegramId: string | null = null;
  let myCharIdStr: string | undefined;
  let theirCharIdStr: string | undefined;

  if (replyTo && replyTo.from && !replyTo.from.is_bot) {
    targetTelegramId = String(replyTo.from.id);
    [myCharIdStr, theirCharIdStr] = parts;
  } else if (parts[0]?.startsWith("@")) {
    const username = parts[0].slice(1);
    const found = await getUserByUsername(username);
    if (!found) {
      await ctx.reply(`❌ <b>${escapeHtml(parts[0])}</b> hasn't used the bot yet! Ask them to /start it first.`, { parse_mode: "HTML" });
      return;
    }
    targetTelegramId = found.telegramId;
    [, myCharIdStr, theirCharIdStr] = parts;
  } else {
    await ctx.reply(
      `❌ <b>Trade Usage:</b>\n\n` +
        `<b>Reply to target user's message:</b>\n` +
        `<code>/trade [your_char_id] [their_char_id]</code>\n\n` +
        `<b>Or mention them:</b>\n` +
        `<code>/trade @username [your_char_id] [their_char_id]</code>\n\n` +
        `Use /harem to see character IDs.`,
      { parse_mode: "HTML" },
    );
    return;
  }

  const myCharId = parseInt(myCharIdStr ?? "");
  const theirCharId = parseInt(theirCharIdStr ?? "");

  if (isNaN(myCharId) || isNaN(theirCharId)) {
    await ctx.reply("❌ Please provide two valid character IDs!\n\nExample: /trade 12 34 (while replying)");
    return;
  }

  if (String(ctx.from.id) === targetTelegramId) {
    await ctx.reply("❌ You can't trade with yourself!");
    return;
  }

  const offerer = await getOrCreateUser(ctx.from);
  const myChar = await getCharWithOwner(myCharId, offerer.id);
  if (!myChar) {
    await ctx.reply("❌ You don't own that character! Use /harem to see your collection.");
    return;
  }

  const receiver = await getUserByTelegramId(targetTelegramId!);
  if (!receiver) {
    await ctx.reply("❌ That user hasn't used the bot yet. Ask them to /start first!");
    return;
  }

  if (String(ctx.from.id) === receiver.telegramId) {
    await ctx.reply("❌ You can't trade with yourself!");
    return;
  }

  const theirChar = await getCharWithOwner(theirCharId, receiver.id);
  if (!theirChar) {
    await ctx.reply(`❌ <b>${escapeHtml(receiver.firstName)}</b> doesn't have character #${theirCharId}!`, { parse_mode: "HTML" });
    return;
  }

  const [trade] = await db
    .insert(botTradesTable)
    .values({
      offererTelegramId: String(ctx.from.id),
      receiverTelegramId: targetTelegramId!,
      offeredUserCharId: myCharId,
      wantedUserCharId: theirCharId,
      chatId: String(ctx.chat!.id),
      status: "pending",
    })
    .returning();

  const tradeMsg = await ctx.reply(
    `🔄 <b>Trade Offer!</b>\n\n` +
      `<b>${escapeHtml(offerer.firstName)}</b> offers:\n` +
      `${getRarityEmoji(myChar.rarity)} <b>${escapeHtml(myChar.name)}</b> (${myChar.anime})\n\n` +
      `In exchange for:\n` +
      `${getRarityEmoji(theirChar.rarity)} <b>${escapeHtml(theirChar.name)}</b> (${theirChar.anime})\n\n` +
      `<b>${escapeHtml(receiver.firstName)}</b>, do you accept this trade?`,
    {
      parse_mode: "HTML",
      reply_markup: Markup.inlineKeyboard([
        [
          Markup.button.callback("✅ Accept", `trade_accept_${trade!.id}_${receiver.telegramId}`),
          Markup.button.callback("❌ Decline", `trade_decline_${trade!.id}_${receiver.telegramId}`),
        ],
      ]).reply_markup,
    },
  );

  await db.update(botTradesTable).set({ messageId: tradeMsg.message_id }).where(eq(botTradesTable.id, trade!.id));
}

export async function handleTradeAccept(ctx: Context & { match: RegExpMatchArray }): Promise<void> {
  if (!ctx.from) return;
  const tradeId = parseInt(ctx.match[1] ?? "");
  const receiverId = ctx.match[2];

  if (String(ctx.from.id) !== receiverId) {
    await ctx.answerCbQuery("This trade offer is not for you! 😤", { show_alert: true });
    return;
  }

  const rows = await db.select().from(botTradesTable).where(eq(botTradesTable.id, tradeId)).limit(1);
  const trade = rows[0];

  if (!trade) { await ctx.answerCbQuery("Trade not found!", { show_alert: true }); return; }
  if (trade.status !== "pending") { await ctx.answerCbQuery("This trade is no longer active!", { show_alert: true }); return; }

  const offerer = await getUserByTelegramId(trade.offererTelegramId);
  const receiver = await getUserByTelegramId(trade.receiverTelegramId);

  if (!offerer || !receiver) { await ctx.answerCbQuery("Error: users not found!", { show_alert: true }); return; }

  await db.update(botUserCharactersTable).set({ userId: receiver.id }).where(eq(botUserCharactersTable.id, trade.offeredUserCharId));

  if (trade.wantedUserCharId) {
    await db.update(botUserCharactersTable).set({ userId: offerer.id }).where(eq(botUserCharactersTable.id, trade.wantedUserCharId));
  }

  await db.update(botTradesTable).set({ status: "accepted" }).where(eq(botTradesTable.id, tradeId));

  try {
    await ctx.editMessageText(
      `✅ <b>Trade Completed!</b>\n\n` +
        `<b>${escapeHtml(offerer.firstName)}</b> and <b>${escapeHtml(receiver.firstName)}</b> successfully swapped characters!`,
      { parse_mode: "HTML" },
    );
  } catch {}

  await ctx.answerCbQuery("Trade accepted! ✅");
}

export async function handleTradeDecline(ctx: Context & { match: RegExpMatchArray }): Promise<void> {
  if (!ctx.from) return;
  const tradeId = parseInt(ctx.match[1] ?? "");
  const receiverId = ctx.match[2];

  if (String(ctx.from.id) !== receiverId) {
    await ctx.answerCbQuery("This is not your trade! 😤", { show_alert: true });
    return;
  }

  await db.update(botTradesTable).set({ status: "declined" }).where(eq(botTradesTable.id, tradeId));

  try {
    await ctx.editMessageText(`❌ <b>Trade Declined.</b>`, { parse_mode: "HTML" });
  } catch {}

  await ctx.answerCbQuery("Trade declined.");
}
