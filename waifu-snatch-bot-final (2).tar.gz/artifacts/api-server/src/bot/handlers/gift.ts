import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botUserCharactersTable, botCharactersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  getOrCreateUser,
  getUserByTelegramId,
  getUserByUsername,
  getRarityEmoji,
  getRarityLabel,
  escapeHtml,
} from "../utils";

export async function handleGift(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.message) return;

  const text = "text" in ctx.message ? ctx.message.text : "";
  const parts = text.trim().split(/\s+/).slice(1);
  const replyTo = "reply_to_message" in ctx.message ? ctx.message.reply_to_message : null;

  let targetTelegramId: string | null = null;
  let charIdStr: string | undefined;

  if (replyTo && replyTo.from && !replyTo.from.is_bot) {
    targetTelegramId = String(replyTo.from.id);
    [charIdStr] = parts;
  } else if (parts[0]?.startsWith("@")) {
    const found = await getUserByUsername(parts[0].slice(1));
    if (!found) {
      await ctx.reply(
        `❌ <b>${escapeHtml(parts[0])}</b> hasn't used the bot yet! Ask them to /start first.`,
        { parse_mode: "HTML" },
      );
      return;
    }
    targetTelegramId = found.telegramId;
    [, charIdStr] = parts;
  } else {
    await ctx.reply(
      `🎁 <b>Gift a character!</b>\n\n` +
        `<b>Reply to someone's message:</b>\n<code>/gift [your_char_id]</code>\n\n` +
        `<b>Or mention them:</b>\n<code>/gift @username [your_char_id]</code>\n\n` +
        `Use /harem to find character IDs.`,
      { parse_mode: "HTML" },
    );
    return;
  }

  const charId = parseInt(charIdStr ?? "");
  if (isNaN(charId)) { await ctx.reply("❌ Invalid character ID!"); return; }

  if (String(ctx.from.id) === targetTelegramId) {
    await ctx.reply("❌ You can't gift to yourself!");
    return;
  }

  const giver = await getOrCreateUser(ctx.from);
  const myChar = await db
    .select({
      ucId: botUserCharactersTable.id,
      name: botCharactersTable.name,
      anime: botCharactersTable.anime,
      rarity: botCharactersTable.rarity,
    })
    .from(botUserCharactersTable)
    .innerJoin(botCharactersTable, eq(botUserCharactersTable.characterId, botCharactersTable.id))
    .where(and(eq(botUserCharactersTable.id, charId), eq(botUserCharactersTable.userId, giver.id)))
    .limit(1);

  if (!myChar[0]) {
    await ctx.reply("❌ You don't own that character! Use /harem to see your collection.");
    return;
  }

  const receiver = await getUserByTelegramId(targetTelegramId!);
  if (!receiver) {
    await ctx.reply("❌ That user hasn't used the bot yet. Ask them to /start first!");
    return;
  }

  const char = myChar[0]!;
  await db
    .update(botUserCharactersTable)
    .set({ userId: receiver.id, isFavorite: false })
    .where(eq(botUserCharactersTable.id, char.ucId));

  await ctx.reply(
    `🎁 <b>Gift Sent!</b>\n\n` +
      `<b>${escapeHtml(giver.firstName)}</b> gifted <b>${escapeHtml(receiver.firstName)}</b>:\n` +
      `${getRarityEmoji(char.rarity)} <b>${escapeHtml(char.name)}</b>\n` +
      `📺 ${escapeHtml(char.anime)}\n` +
      `✨ ${getRarityLabel(char.rarity)}`,
    { parse_mode: "HTML" },
  );
}
