import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botRedeemCodesTable, botUserCodesTable, botUsersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { getOrCreateUser, isOwner, isSudoAdmin, escapeHtml } from "../utils";
import { bot } from "../bot-instance";

export async function handleRedeem(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.message) return;

  const text = "text" in ctx.message ? ctx.message.text : "";
  const code = text.trim().split(/\s+/)[1]?.toUpperCase();

  if (!code) {
    await ctx.reply(
      `🎁 <b>Redeem a Code!</b>\n\n<code>/redeem [CODE]</code>\n\n<i>Codes give you free coins or special rewards!\nCodes are shared in the updates channel.</i>`,
      { parse_mode: "HTML" },
    );
    return;
  }

  const user = await getOrCreateUser(ctx.from);

  const codeRows = await db.select().from(botRedeemCodesTable).where(eq(botRedeemCodesTable.code, code)).limit(1);
  const redeemCode = codeRows[0];

  if (!redeemCode) { await ctx.reply("❌ Invalid code! Double-check and try again."); return; }
  if (redeemCode.expiresAt && redeemCode.expiresAt < new Date()) { await ctx.reply("❌ This code has expired!"); return; }
  if (redeemCode.usedCount >= redeemCode.maxUses) { await ctx.reply("❌ This code has been fully redeemed and is no longer valid!"); return; }

  const alreadyUsed = await db
    .select()
    .from(botUserCodesTable)
    .where(and(eq(botUserCodesTable.userId, user.id), eq(botUserCodesTable.codeId, redeemCode.id)))
    .limit(1);

  if (alreadyUsed.length > 0) { await ctx.reply("❌ You have already redeemed this code!"); return; }

  await db.insert(botUserCodesTable).values({ userId: user.id, codeId: redeemCode.id });
  await db.update(botRedeemCodesTable).set({ usedCount: redeemCode.usedCount + 1 }).where(eq(botRedeemCodesTable.id, redeemCode.id));
  await db.update(botUsersTable).set({ coins: user.coins + redeemCode.rewardCoins }).where(eq(botUsersTable.id, user.id));

  const display = ctx.from.username ? `@${ctx.from.username}` : escapeHtml(ctx.from.first_name);

  await ctx.reply(
    `🎉 <b>Code Redeemed!</b>\n\n` +
      `Code: <code>${escapeHtml(code)}</code>\n` +
      `💰 <b>+${redeemCode.rewardCoins.toLocaleString()} coins!</b>\n\n` +
      `New Balance: <b>${(user.coins + redeemCode.rewardCoins).toLocaleString()} coins</b>`,
    { parse_mode: "HTML" },
  );

  const ownerId = process.env.OWNER_ID;
  if (ownerId) {
    try {
      await bot.telegram.sendMessage(
        ownerId,
        `🔔 <b>Code Redeemed!</b>\n\nUser: ${display} (ID: <code>${ctx.from.id}</code>)\nCode: <code>${escapeHtml(code)}</code>\nCoins: <b>+${redeemCode.rewardCoins.toLocaleString()}</b>\nUses: ${redeemCode.usedCount + 1}/${redeemCode.maxUses}`,
        { parse_mode: "HTML" },
      );
    } catch {}
  }
}

export async function handleGen(ctx: Context): Promise<void> {
  if (!ctx.from) return;
  if (!(await isSudoAdmin(String(ctx.from.id)))) {
    await ctx.reply("❌ Only admins can generate codes!");
    return;
  }

  const text = "text" in ctx.message! ? ctx.message!.text : "";
  const parts = text.trim().split(/\s+/);

  if (parts.length < 4) {
    await ctx.reply(
      `📋 <b>Generate Redeem Code</b>\n\n<code>/gen [CODE] [coins] [max_uses]</code>\n\nExample: <code>/gen WELCOME100 100 50</code>`,
      { parse_mode: "HTML" },
    );
    return;
  }

  const code = parts[1]!.toUpperCase();
  const coins = parseInt(parts[2]!, 10);
  const maxUses = parseInt(parts[3]!, 10);

  if (isNaN(coins) || coins <= 0) { await ctx.reply("❌ Invalid coin amount!"); return; }
  if (isNaN(maxUses) || maxUses <= 0) { await ctx.reply("❌ Invalid max uses!"); return; }

  const existing = await db.select({ id: botRedeemCodesTable.id }).from(botRedeemCodesTable).where(eq(botRedeemCodesTable.code, code)).limit(1);
  if (existing.length > 0) { await ctx.reply(`❌ Code <code>${escapeHtml(code)}</code> already exists!`, { parse_mode: "HTML" }); return; }

  await db.insert(botRedeemCodesTable).values({ code, rewardCoins: coins, maxUses, createdBy: String(ctx.from.id) });

  await ctx.reply(
    `✅ <b>Code Created!</b>\n\nCode: <code>${escapeHtml(code)}</code>\nCoins: <b>${coins.toLocaleString()}</b>\nMax Uses: <b>${maxUses}</b>`,
    { parse_mode: "HTML" },
  );
}

export async function handleCodeList(ctx: Context): Promise<void> {
  if (!ctx.from) return;
  if (!(await isSudoAdmin(String(ctx.from.id)))) { await ctx.reply("❌ Only admins can view code list!"); return; }

  const codes = await db.select().from(botRedeemCodesTable).limit(20);

  if (codes.length === 0) { await ctx.reply("📋 No active codes."); return; }

  const lines = codes.map(
    (c) => `• <code>${escapeHtml(c.code)}</code> — ${c.rewardCoins} coins | ${c.usedCount}/${c.maxUses} used${c.expiresAt ? ` | Exp: ${c.expiresAt.toLocaleDateString()}` : ""}`,
  );

  await ctx.reply(`📋 <b>Redeem Codes (${codes.length})</b>\n\n${lines.join("\n")}`, { parse_mode: "HTML" });
}

export async function handleDelCode(ctx: Context): Promise<void> {
  if (!ctx.from) return;
  if (!isOwner(String(ctx.from.id))) { await ctx.reply("❌ Only the owner can delete codes!"); return; }

  const text = "text" in ctx.message! ? ctx.message!.text : "";
  const code = text.trim().split(/\s+/)[1]?.toUpperCase();

  if (!code) { await ctx.reply(`<code>/delcode [CODE]</code>`, { parse_mode: "HTML" }); return; }

  const deleted = await db.delete(botRedeemCodesTable).where(eq(botRedeemCodesTable.code, code)).returning({ code: botRedeemCodesTable.code });

  if (deleted.length === 0) {
    await ctx.reply(`❌ Code <code>${escapeHtml(code)}</code> not found!`, { parse_mode: "HTML" });
    return;
  }

  await ctx.reply(`✅ Code <code>${escapeHtml(code)}</code> deleted!`, { parse_mode: "HTML" });
}
