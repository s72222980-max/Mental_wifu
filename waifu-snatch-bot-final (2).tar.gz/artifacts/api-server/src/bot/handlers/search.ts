import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botCharactersTable, botUserCharactersTable } from "@workspace/db";
import { eq, sql, count } from "drizzle-orm";
import { getOrCreateUser, getRarityEmoji, getRarityLabel, escapeHtml } from "../utils";

export async function handleSearch(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.message) return;

  const text = "text" in ctx.message ? ctx.message.text : "";
  const query = text.trim().split(/\s+/).slice(1).join(" ").trim();

  if (!query || query.length < 2) {
    await ctx.reply(
      `🔍 <b>Search Characters</b>\n\n<code>/search [character name]</code>\n\nExample: <code>/search Naruto</code>`,
      { parse_mode: "HTML" },
    );
    return;
  }

  if (query.length > 50) { await ctx.reply("❌ Search query too long!"); return; }

  const results = await db
    .select()
    .from(botCharactersTable)
    .where(sql`LOWER(${botCharactersTable.name}) LIKE LOWER(${"%" + query + "%"})`)
    .orderBy(botCharactersTable.favourites)
    .limit(10);

  if (results.length === 0) {
    await ctx.reply(
      `🔍 No results for <b>"${escapeHtml(query)}"</b>\n\n<i>Try a different spelling or partial name.</i>`,
      { parse_mode: "HTML" },
    );
    return;
  }

  const user = await getOrCreateUser(ctx.from);

  const owned = await db
    .select({ characterId: botUserCharactersTable.characterId, cnt: count() })
    .from(botUserCharactersTable)
    .where(eq(botUserCharactersTable.userId, user.id))
    .groupBy(botUserCharactersTable.characterId);

  const ownedMap = new Map(owned.map((o) => [o.characterId, Number(o.cnt)]));

  const lines = results.map((c) => {
    const copies = ownedMap.get(c.id) ?? 0;
    const ownedStr = copies > 0 ? ` ✅${copies > 1 ? ` ×${copies}` : ""}` : "";
    return `${getRarityEmoji(c.rarity)} <b>${escapeHtml(c.name)}</b>${ownedStr}\n   📺 ${escapeHtml(c.anime)} | ${getRarityLabel(c.rarity)}`;
  });

  await ctx.reply(
    `🔍 <b>Search: "${escapeHtml(query)}"</b> (${results.length} result${results.length !== 1 ? "s" : ""})\n\n` +
      lines.join("\n\n") +
      `\n\n<i>✅ = you own it | Sorted by popularity</i>`,
    { parse_mode: "HTML" },
  );
}
