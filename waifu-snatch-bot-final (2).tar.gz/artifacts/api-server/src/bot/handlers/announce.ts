import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botGroupStatsTable } from "@workspace/db";
import { isOwner, escapeHtml, PE } from "../utils";
import { bot } from "../bot-instance";
import { logger } from "../../lib/logger";

export async function handleAnnounce(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.message) return;

  if (!isOwner(String(ctx.from.id))) {
    await ctx.reply(`${PE.cross} Sirf owner ye command use kar sakta hai!`);
    return;
  }

  const text = "text" in ctx.message ? ctx.message.text : "";
  const message = text.trim().split(/\n|\s+/).slice(1).join(" ").trim() ||
    text.trim().replace(/^\/announce\S*\s*/i, "").trim();

  if (!message) {
    await ctx.reply(
      `${PE.warning} <b>Usage:</b>\n\n` +
      `<code>/announce Aapka message yahan likhein</code>\n\n` +
      `<i>Ye message sabhi active groups mein bheja jayega.</i>`,
      { parse_mode: "HTML" },
    );
    return;
  }

  const groups = await db
    .select({ groupId: botGroupStatsTable.groupId })
    .from(botGroupStatsTable);

  if (groups.length === 0) {
    await ctx.reply(`${PE.warning} Koi active group nahi mila!`);
    return;
  }

  const announcementText =
    `${PE.party} <b>╔══════════════════╗</b>\n` +
    `${PE.star}  <b>𝗔𝗡𝗡𝗢𝗨𝗡𝗖𝗘𝗠𝗘𝗡𝗧</b>\n` +
    `${PE.party} <b>╚══════════════════╝</b>\n\n` +
    `${escapeHtml(message)}\n\n` +
    `${PE.heart} <i>— Snatch Bot Team</i>`;

  const status = await ctx.reply(
    `${PE.hourglass} <b>Bhej raha hun...</b> 0 / ${groups.length} groups`,
    { parse_mode: "HTML" },
  );

  let sent = 0;
  let failed = 0;

  for (const group of groups) {
    try {
      await bot.telegram.sendMessage(group.groupId, announcementText, {
        parse_mode: "HTML",
      });
      sent++;
    } catch {
      failed++;
    }
    await new Promise((r) => setTimeout(r, 50));
  }

  logger.info({ sent, failed, total: groups.length }, "Announce complete");

  try {
    await bot.telegram.editMessageText(
      ctx.chat!.id,
      status.message_id,
      undefined,
      `${PE.check} <b>Announcement Done!</b>\n\n` +
      `${PE.rocket} Bheja: <b>${sent}</b> groups\n` +
      `${PE.cross} Failed: <b>${failed}</b>\n` +
      `📊 Total: <b>${groups.length}</b>`,
      { parse_mode: "HTML" },
    );
  } catch {}
}
