import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botUsersTable, botUserCharactersTable, botCharactersTable } from "@workspace/db";
import { eq, desc, count } from "drizzle-orm";
import { getOrCreateUser, checkPremium, getRarityEmoji, getRarityLabel, escapeHtml, PE } from "../utils";

const RARITY_ORDER: Record<string, number> = { legendary: 4, epic: 3, rare: 2, common: 1 };

export async function handleProfile(ctx: Context): Promise<void> {
  if (!ctx.from) return;
  const user = await getOrCreateUser(ctx.from);
  const isPremium = await checkPremium(String(ctx.from.id));

  const [totalRows, rankRows] = await Promise.all([
    db.select({ count: count() }).from(botUserCharactersTable).where(eq(botUserCharactersTable.userId, user.id)),
    db.select({ id: botUsersTable.id }).from(botUsersTable).orderBy(desc(botUsersTable.totalCaught)),
  ]);

  const totalOwned = Number(totalRows[0]?.count ?? 0);
  const rank = rankRows.findIndex((r) => r.id === user.id) + 1;

  const bestChars = await db
    .select({ name: botCharactersTable.name, rarity: botCharactersTable.rarity, anime: botCharactersTable.anime })
    .from(botUserCharactersTable)
    .innerJoin(botCharactersTable, eq(botUserCharactersTable.characterId, botCharactersTable.id))
    .where(eq(botUserCharactersTable.userId, user.id))
    .limit(50);

  const sorted = bestChars.sort((a, b) => (RARITY_ORDER[b.rarity] ?? 0) - (RARITY_ORDER[a.rarity] ?? 0));
  const top = sorted[0];
  const badge = isPremium ? ` ${PE.crown}` : "";

  await ctx.reply(
    `👤 <b>${escapeHtml(user.firstName)}'s Profile${badge}</b>\n\n` +
      `${PE.coin} <b>Coins:</b> ${user.coins.toLocaleString()}\n` +
      `🎴 <b>Total Caught:</b> ${user.totalCaught.toLocaleString()}\n` +
      `📦 <b>Collection:</b> ${totalOwned} cards\n` +
      `${PE.trophy} <b>Global Rank:</b> #${rank}\n` +
      `${PE.fire} <b>Daily Streak:</b> ${user.streakDays} day${user.streakDays !== 1 ? "s" : ""}\n` +
      (isPremium ? `${PE.star} <b>Premium:</b> Active\n` : "") +
      (top
        ? `\n${PE.sparkles} <b>Best Character:</b>\n${getRarityEmoji(top.rarity)} <b>${escapeHtml(top.name)}</b> — ${escapeHtml(top.anime)}\n<blockquote>${getRarityLabel(top.rarity)}</blockquote>`
        : `\n<blockquote>Catch characters in a group to build your collection!</blockquote>`),
    { parse_mode: "HTML" },
  );
}
