import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botUserCharactersTable, botCharactersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { getOrCreateUser, getUserByTelegramId, escapeHtml } from "../utils";
import { buildHaremData } from "./harem";

export async function handleFav(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.message) return;
  const text = "text" in ctx.message ? ctx.message.text : "";
  const charIdStr = text.trim().split(/\s+/)[1];

  if (!charIdStr) {
    await ctx.reply(
      "⭐ <b>Favourite Usage:</b>\n\n<code>/fav [collection_id]</code>\n\nUse /harem to find character IDs.",
      { parse_mode: "HTML" },
    );
    return;
  }

  const charId = parseInt(charIdStr);
  if (isNaN(charId)) { await ctx.reply("❌ Invalid ID!"); return; }

  const user = await getOrCreateUser(ctx.from);

  const rows = await db
    .select({
      ucId: botUserCharactersTable.id,
      isFavorite: botUserCharactersTable.isFavorite,
      name: botCharactersTable.name,
      rarity: botCharactersTable.rarity,
    })
    .from(botUserCharactersTable)
    .innerJoin(botCharactersTable, eq(botUserCharactersTable.characterId, botCharactersTable.id))
    .where(and(eq(botUserCharactersTable.id, charId), eq(botUserCharactersTable.userId, user.id)))
    .limit(1);

  const char = rows[0];
  if (!char) {
    await ctx.reply("❌ Character not found in your collection!");
    return;
  }

  const newFav = !char.isFavorite;
  await db
    .update(botUserCharactersTable)
    .set({ isFavorite: newFav })
    .where(eq(botUserCharactersTable.id, charId));

  const action = newFav ? "added to" : "removed from";
  await ctx.reply(
    `${newFav ? "⭐" : "☆"} <b>${escapeHtml(char.name)}</b> ${action} favourites!`,
    { parse_mode: "HTML" },
  );
}

export async function handleFavToggleCallback(ctx: Context & { match: RegExpMatchArray }): Promise<void> {
  if (!ctx.from) return;
  const ucId = parseInt(ctx.match[1] ?? "");
  const telegramId = ctx.match[2] ?? "";
  const page = parseInt(ctx.match[3] ?? "1");

  if (String(ctx.from.id) !== telegramId) {
    await ctx.answerCbQuery("This is not your harem! 😤", { show_alert: true });
    return;
  }

  const user = await getUserByTelegramId(telegramId);
  if (!user) { await ctx.answerCbQuery(); return; }

  const rows = await db
    .select({ isFavorite: botUserCharactersTable.isFavorite })
    .from(botUserCharactersTable)
    .where(and(eq(botUserCharactersTable.id, ucId), eq(botUserCharactersTable.userId, user.id)))
    .limit(1);

  if (!rows[0]) { await ctx.answerCbQuery("Character not found!"); return; }

  const newFav = !rows[0].isFavorite;
  await db
    .update(botUserCharactersTable)
    .set({ isFavorite: newFav })
    .where(eq(botUserCharactersTable.id, ucId));

  const data = await buildHaremData(user.id, page, telegramId);
  if (!data) { await ctx.answerCbQuery(); return; }

  try {
    await ctx.editMessageMedia(
      { type: "photo", media: data.imageUrl, caption: data.caption, parse_mode: "HTML" },
      { reply_markup: data.keyboard.reply_markup },
    );
  } catch {}

  await ctx.answerCbQuery(newFav ? "⭐ Added to favourites!" : "☆ Removed from favourites!");
}
