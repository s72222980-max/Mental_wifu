import type { Context } from "telegraf";
import { Markup } from "telegraf";
import { db } from "@workspace/db";
import { botUserCharactersTable, botCharactersTable, botUsersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { getOrCreateUser, getRarityEmoji, getBurnCoins, escapeHtml } from "../utils";

export async function handleBurn(ctx: Context): Promise<void> {
  if (!ctx.from || !ctx.message) return;

  const text = "text" in ctx.message ? ctx.message.text : "";
  const charIdStr = text.trim().split(/\s+/)[1];

  if (!charIdStr) {
    await ctx.reply(
      "🔥 <b>Burn Usage:</b>\n\n<code>/burn [collection_id]</code>\n\nBurning a character gives you coins!\nUse /harem to find character IDs.",
      { parse_mode: "HTML" },
    );
    return;
  }

  const charId = parseInt(charIdStr);
  if (isNaN(charId)) { await ctx.reply("❌ Invalid ID!"); return; }

  const user = await getOrCreateUser(ctx.from);

  const rows = await db
    .select({
      ucId: botUserCharactersTable.id,
      name: botCharactersTable.name,
      anime: botCharactersTable.anime,
      rarity: botCharactersTable.rarity,
      imageUrl: botCharactersTable.imageUrl,
    })
    .from(botUserCharactersTable)
    .innerJoin(botCharactersTable, eq(botUserCharactersTable.characterId, botCharactersTable.id))
    .where(and(eq(botUserCharactersTable.id, charId), eq(botUserCharactersTable.userId, user.id)))
    .limit(1);

  const char = rows[0];
  if (!char) {
    await ctx.reply("❌ Character not found in your collection!\n\nUse /harem to see your collection.");
    return;
  }

  const coins = getBurnCoins(char.rarity);

  await ctx.reply(
    `🔥 <b>Burn Character?</b>\n\n` +
      `${getRarityEmoji(char.rarity)} <b>${escapeHtml(char.name)}</b>\n` +
      `📺 ${escapeHtml(char.anime)}\n\n` +
      `💰 You'll receive: <b>${coins} coins</b>\n\n` +
      `<b>This cannot be undone!</b>`,
    {
      parse_mode: "HTML",
      reply_markup: Markup.inlineKeyboard([
        [
          Markup.button.callback("🔥 Burn!", `burn_confirm_${charId}_${user.id}`),
          Markup.button.callback("❌ Cancel", "burn_cancel"),
        ],
      ]).reply_markup,
    },
  );
}

export async function handleBurnConfirm(ctx: Context & { match: RegExpMatchArray }): Promise<void> {
  if (!ctx.from) return;
  const charId = parseInt(ctx.match[1] ?? "");
  const userId = parseInt(ctx.match[2] ?? "");

  if (isNaN(charId) || isNaN(userId)) {
    await ctx.answerCbQuery("Invalid request!", { show_alert: true });
    return;
  }

  const user = await getOrCreateUser(ctx.from);

  if (user.id !== userId) {
    await ctx.answerCbQuery("This is not your character! 😤", { show_alert: true });
    return;
  }

  const rows = await db
    .select({
      ucId: botUserCharactersTable.id,
      name: botCharactersTable.name,
      rarity: botCharactersTable.rarity,
    })
    .from(botUserCharactersTable)
    .innerJoin(botCharactersTable, eq(botUserCharactersTable.characterId, botCharactersTable.id))
    .where(and(eq(botUserCharactersTable.id, charId), eq(botUserCharactersTable.userId, user.id)))
    .limit(1);

  const char = rows[0];
  if (!char) {
    await ctx.answerCbQuery("Character not found or already burned!", { show_alert: true });
    return;
  }

  const coins = getBurnCoins(char.rarity);

  await db.delete(botUserCharactersTable).where(eq(botUserCharactersTable.id, charId));
  await db
    .update(botUsersTable)
    .set({ coins: user.coins + coins })
    .where(eq(botUsersTable.id, user.id));

  try {
    await ctx.editMessageText(
      `🔥 <b>${escapeHtml(char.name)}</b> was burned!\n\n💰 You received <b>${coins} coins</b>!`,
      { parse_mode: "HTML" },
    );
  } catch {}

  await ctx.answerCbQuery(`+${coins} coins! 💰`);
}

export async function handleBurnCancel(ctx: Context): Promise<void> {
  try {
    await ctx.editMessageText("❌ Burn cancelled.");
  } catch {}
  await ctx.answerCbQuery("Cancelled.");
}
