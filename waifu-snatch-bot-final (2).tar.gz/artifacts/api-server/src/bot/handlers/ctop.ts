import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botGroupCatchesTable, botUsersTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { escapeHtml, PE } from "../utils";

const MEDALS = [
  `<tg-emoji emoji-id="5471952986970267163">🥇</tg-emoji>`,
  `<tg-emoji emoji-id="5445037397672479558">🥈</tg-emoji>`,
  `<tg-emoji emoji-id="5462882007451185227">🥉</tg-emoji>`,
];

export async function handleCtop(ctx: Context): Promise<void> {
  const chat = ctx.chat;
  if (!chat || (chat.type !== "group" && chat.type !== "supergroup")) {
    await ctx.reply(`⚠️ <b>Ye command sirf group mein chalti hai!</b>`, { parse_mode: "HTML" });
    return;
  }

  const groupId = String(chat.id);

  const rows = await db
    .select({
      caughtCount: botGroupCatchesTable.caughtCount,
      firstName: botUsersTable.firstName,
      username: botUsersTable.username,
    })
    .from(botGroupCatchesTable)
    .innerJoin(botUsersTable, eq(botGroupCatchesTable.userId, botUsersTable.id))
    .where(eq(botGroupCatchesTable.groupId, groupId))
    .orderBy(desc(botGroupCatchesTable.caughtCount))
    .limit(10);

  if (rows.length === 0) {
    await ctx.reply(
      `${PE.trophy} <b>Is group mein abhi koi catches nahi!</b>\n\n` +
      `${PE.lightning} Baat karo — har 20 messages pe ek character spawn hoga!`,
      { parse_mode: "HTML" },
    );
    return;
  }

  const groupName = "title" in chat ? escapeHtml(chat.title) : "This Group";

  const lines = rows.map((u, i) => {
    const medal = MEDALS[i] ?? `<b>${i + 1}.</b>`;
    const name = u.username ? `@${escapeHtml(u.username)}` : escapeHtml(u.firstName);
    return `${medal} <b>${name}</b> — ${PE.sword} ${u.caughtCount} caught`;
  });

  await ctx.reply(
    `${PE.trophy} <b>Top Hunters — ${groupName}</b>\n` +
    `${PE.sparkles}━━━━━━━━━━━━━━━━━━\n\n` +
    lines.join("\n") +
    `\n\n${PE.sparkles}━━━━━━━━━━━━━━━━━━\n` +
    `<blockquote>Use /name [character name] to catch &amp; climb the board!</blockquote>`,
    { parse_mode: "HTML" },
  );
}
