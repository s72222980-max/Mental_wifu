import type { Context } from "telegraf";
import { Markup } from "telegraf";
import { db } from "@workspace/db";
import { botUserCharactersTable, botCharactersTable } from "@workspace/db";
import { eq, desc, count } from "drizzle-orm";
import {
  getOrCreateUser,
  getUserByTelegramId,
  getRarityEmoji,
  getRarityLabel,
  escapeHtml,
  formatDate,
  PE,
} from "../utils";

async function buildHaremData(userId: number, page: number, telegramId: string) {
  const totalRows = await db
    .select({ count: count() })
    .from(botUserCharactersTable)
    .where(eq(botUserCharactersTable.userId, userId));

  const total = Number(totalRows[0]?.count ?? 0);
  if (total === 0) return null;

  const safePage = Math.min(Math.max(1, page), total);

  const chars = await db
    .select({
      ucId: botUserCharactersTable.id,
      name: botCharactersTable.name,
      anime: botCharactersTable.anime,
      rarity: botCharactersTable.rarity,
      imageUrl: botCharactersTable.imageUrl,
      isFavorite: botUserCharactersTable.isFavorite,
      caughtAt: botUserCharactersTable.caughtAt,
    })
    .from(botUserCharactersTable)
    .innerJoin(botCharactersTable, eq(botUserCharactersTable.characterId, botCharactersTable.id))
    .where(eq(botUserCharactersTable.userId, userId))
    .orderBy(desc(botUserCharactersTable.caughtAt))
    .limit(1)
    .offset(safePage - 1);

  const char = chars[0];
  if (!char) return null;

  const favStar = char.isFavorite ? "⭐" : "☆";

  const caption =
    `${PE.cherry} <b>Harem</b> — ${total} character${total !== 1 ? "s" : ""}\n\n` +
    `${getRarityEmoji(char.rarity)} <b>${escapeHtml(char.name)}</b>\n` +
    `🎭 <b>Anime:</b> ${escapeHtml(char.anime)}\n` +
    `${PE.sparkles} ${getRarityLabel(char.rarity)}\n` +
    `🆔 <b>ID:</b> #${char.ucId}\n` +
    `📅 ${formatDate(char.caughtAt)}` +
    (char.isFavorite ? `\n${PE.star} <i>Favourite</i>` : "");

  const prevCb = safePage <= 1 ? "noop" : `harem_${safePage - 1}_${telegramId}`;
  const nextCb = safePage >= total ? "noop" : `harem_${safePage + 1}_${telegramId}`;

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback(safePage <= 1 ? "·" : "◀ Prev", prevCb),
      Markup.button.callback(`${safePage} / ${total}`, "noop"),
      Markup.button.callback(safePage >= total ? "·" : "Next ▶", nextCb),
    ],
    [
      Markup.button.callback(`${favStar} Favourite`, `fav_toggle_${char.ucId}_${telegramId}_${safePage}`),
    ],
  ]);

  return { imageUrl: char.imageUrl, caption, keyboard };
}

export async function handleHarem(ctx: Context): Promise<void> {
  if (!ctx.from) return;
  const user = await getOrCreateUser(ctx.from);
  const data = await buildHaremData(user.id, 1, String(ctx.from.id));

  if (!data) {
    const sgLink = process.env.SUPPORT_GROUP_LINK ?? "https://t.me/+tm6dr4ZEyZE5ZjNl";
    const ucLink = process.env.UPDATES_CHANNEL_LINK ?? "https://t.me/ABOUTxYUTAA";
    await ctx.reply(
      `${PE.cherry} <b>Your harem is empty!</b>\n\n` +
      `<b>How to get characters:</b>\n` +
      `${PE.gift} Use /superbonus — free character every 24h!\n` +
      `${PE.lightning} Characters also appear in groups — type their name to catch!\n` +
      `${PE.dice} Admins can use /drop to force-spawn one now\n\n` +
      `<blockquote>Join our group and start catching!</blockquote>`,
      {
        parse_mode: "HTML",
        reply_markup: Markup.inlineKeyboard([
          [Markup.button.callback("🎁 Claim Super Bonus", "quick_superbonus")],
          [
            Markup.button.url("👥 Support Group", sgLink),
            Markup.button.url("📢 Updates", ucLink),
          ],
        ]).reply_markup,
      },
    );
    return;
  }

  await ctx.replyWithPhoto(data.imageUrl, {
    caption: data.caption,
    parse_mode: "HTML",
    reply_markup: data.keyboard.reply_markup,
  });
}

export async function handleHaremCallback(ctx: Context & { match: RegExpMatchArray }): Promise<void> {
  if (!ctx.from) return;
  const page = parseInt(ctx.match[1] ?? "1");
  const telegramId = ctx.match[2] ?? "";

  if (String(ctx.from.id) !== telegramId) {
    await ctx.answerCbQuery("This is not your harem! 😤", { show_alert: true });
    return;
  }

  const user = await getUserByTelegramId(telegramId);
  if (!user) { await ctx.answerCbQuery(); return; }

  const data = await buildHaremData(user.id, page, telegramId);
  if (!data) { await ctx.answerCbQuery("Empty harem!"); return; }

  try {
    await ctx.editMessageMedia(
      { type: "photo", media: data.imageUrl, caption: data.caption, parse_mode: "HTML" },
      { reply_markup: data.keyboard.reply_markup },
    );
  } catch {}

  await ctx.answerCbQuery();
}

export { buildHaremData };
