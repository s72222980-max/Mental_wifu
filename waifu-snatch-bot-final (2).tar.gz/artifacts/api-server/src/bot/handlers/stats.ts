import type { Context } from "telegraf";
import { db } from "@workspace/db";
import { botUsersTable, botCharactersTable, botUserCharactersTable } from "@workspace/db";
import { count, sum, desc } from "drizzle-orm";

export async function handleStats(ctx: Context): Promise<void> {
  const [userCount, charCount, catchCount, coinsRow] = await Promise.all([
    db.select({ count: count() }).from(botUsersTable),
    db.select({ count: count() }).from(botCharactersTable),
    db.select({ count: count() }).from(botUserCharactersTable),
    db.select({ total: sum(botUsersTable.coins) }).from(botUsersTable),
  ]);

  const topUser = await db
    .select({ firstName: botUsersTable.firstName, username: botUsersTable.username, totalCaught: botUsersTable.totalCaught })
    .from(botUsersTable)
    .orderBy(desc(botUsersTable.totalCaught))
    .limit(1);

  const total = topUser[0];
  const topName = total
    ? total.username
      ? `@${total.username}`
      : total.firstName
    : "N/A";

  await ctx.reply(
    `📊 <b>Waifu Snatch Bot — Global Stats</b>\n\n` +
      `👥 <b>Total Users:</b> ${Number(userCount[0]?.count ?? 0).toLocaleString()}\n` +
      `🎴 <b>Total Characters:</b> ${Number(charCount[0]?.count ?? 0).toLocaleString()}\n` +
      `🏆 <b>Total Catches:</b> ${Number(catchCount[0]?.count ?? 0).toLocaleString()}\n` +
      `💰 <b>Coins in Circulation:</b> ${Number(coinsRow[0]?.total ?? 0).toLocaleString()}\n\n` +
      `🥇 <b>Top Hunter:</b> ${topName} (${total?.totalCaught ?? 0} catches)\n\n` +
      `<i>Add me to a group and start snatching!</i>`,
    { parse_mode: "HTML" },
  );
}
