import { getBot } from "./bot-instance";
import { handleStart, handleHelp, handleHelpCallback } from "./handlers/start";
import { handleHarem, handleHaremCallback } from "./handlers/harem";
import { handleBal, handlePay } from "./handlers/bal";
import { handleDaily } from "./handlers/daily";
import { handleDrop } from "./handlers/drop";
import { handleView } from "./handlers/view";
import { handleProfile } from "./handlers/profile";
import { handleSearch } from "./handlers/search";
import { handleTop } from "./handlers/top";
import { handleCtop } from "./handlers/ctop";
import { handleStats } from "./handlers/stats";
import { handleStreak } from "./handlers/streak";
import { handleCheck } from "./handlers/check";
import { handleFav, handleFavToggleCallback } from "./handlers/fav";
import { handleGift } from "./handlers/gift";
import { handleBurn, handleBurnConfirm, handleBurnCancel } from "./handlers/burn";
import { handleTrade, handleTradeAccept, handleTradeDecline } from "./handlers/trade";
import { handleWarn, handleWarns, handleUnwarn, handleResetWarns } from "./handlers/warn";
import { handleJackpot } from "./handlers/jackpot";
import { handleRedeem, handleGen, handleCodeList, handleDelCode } from "./handlers/redeem";
import { handlePremium, handleBuyPremium, handleBuyPremiumCallback } from "./handlers/premium";
import { handleSudo, handleAddSudo, handleRemoveSudo, handleSudoList } from "./handlers/sudo";
import { handleSpawnTime, handleSetMsgSpawn, handleSetSpawnTime } from "./handlers/spawntime";
import { handleSuperBonus } from "./handlers/superbonus";
import { handleAnnounce } from "./handlers/announce";
import { handleGroupMessage, handleNameCommand, cleanupExpiredSpawns } from "./spawn";
import { seedCharacters } from "./seed";
import { checkBanned, isOwner, isSudoAdmin } from "./utils";
import { logger } from "../lib/logger";
import type { Context } from "telegraf";

// ─── Config ────────────────────────────────────────────────────────────────

const SUPPORT_GROUP_ID = process.env.SUPPORT_GROUP_ID ?? "@legendd_teamm";
const UPDATES_CHANNEL_ID = process.env.UPDATES_CHANNEL_ID ?? "@ABOUTxYUTAA";
const SUPPORT_GROUP_LINK = process.env.SUPPORT_GROUP_LINK ?? "https://t.me/+tm6dr4ZEyZE5ZjNl";
const UPDATES_CHANNEL_LINK = process.env.UPDATES_CHANNEL_LINK ?? "https://t.me/ABOUTxYUTAA";

// ─── Join check ─────────────────────────────────────────────────────────────

async function checkMembership(telegramId: number, chatId: string): Promise<boolean> {
  const bot = getBot();
  try {
    const member = await bot.telegram.getChatMember(chatId, telegramId);
    return ["member", "administrator", "creator"].includes(member.status);
  } catch {
    return true;
  }
}

// ─── Bot admin check ────────────────────────────────────────────────────────

async function isBotAdmin(chatId: number): Promise<boolean> {
  const bot = getBot();
  try {
    const me = await bot.telegram.getMe();
    const member = await bot.telegram.getChatMember(chatId, me.id);
    return member.status === "administrator" || member.status === "creator";
  } catch {
    return false;
  }
}

// ─── Bot setup ────────────────────────────────────────────────────────────────

export async function startBot(): Promise<void> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    logger.warn("TELEGRAM_BOT_TOKEN not set — bot will not start. Set it in Secrets and restart.");
    return;
  }

  const bot = getBot();

  // ─── When bot is added to a group ───────────────────────────────────────────

  bot.on("my_chat_member", async (ctx) => {
    const update = ctx.myChatMember;
    const chat = update.chat;
    if (chat.type !== "group" && chat.type !== "supergroup") return;

    const newStatus = update.new_chat_member.status;

    // Bot was added to the group
    if (newStatus === "member" || newStatus === "administrator") {
      if (newStatus === "member") {
        // Bot added but NOT admin — ask to be made admin
        try {
          await ctx.telegram.sendMessage(
            chat.id,
            `👋 <b>Hello! Main ${(await bot.telegram.getMe()).first_name} hun!</b>\n\n` +
            `⚠️ <b>Mujhe Admin banana zaroori hai!</b>\n\n` +
            `Admin banaoge tabhi main group mein kaam karunga:\n` +
            `🎯 Characters spawn karuga\n` +
            `🎮 Snatching games chalaunga\n` +
            `⚡ Sab commands active honge\n\n` +
            `<i>Mujhe admin banao, phir /start bhejo!</i>`,
            { parse_mode: "HTML" },
          );
        } catch {}
      } else {
        // Bot was made admin
        try {
          await ctx.telegram.sendMessage(
            chat.id,
            `✅ <b>Admin mil gaya! Ab main active hun!</b>\n\n` +
            `🎉 Is group mein characters spawn hone shuru honge!\n` +
            `📜 Commands dekhne ke liye /help bhejo!\n\n` +
            `<i>Happy Snatching! ⚡</i>`,
            { parse_mode: "HTML" },
          );
        } catch {}
      }
    }
  });

  // ─── Middleware ──────────────────────────────────────────────────────────────

  bot.use(async (ctx, next) => {
    if (!ctx.from) return next();

    // Ban check
    if (await checkBanned(String(ctx.from.id))) return;

    // Private chats — no admin check needed
    const chat = ctx.chat;
    const isGroup = chat && (chat.type === "group" || chat.type === "supergroup");

    // Group mein bot admin hai ya nahi — check karo
    if (isGroup) {
      const adminOk = await isBotAdmin(chat.id);
      if (!adminOk) {
        // Sirf commands pe reply karo, normal messages ignore karo
        const text = ctx.message && "text" in ctx.message ? ctx.message.text : "";
        if (text.startsWith("/")) {
          await ctx.reply(
            `⚠️ <b>Mujhe pehle Admin banao!</b>\n\n` +
            `Main tabhi kaam karunga jab mujhe is group ka Admin banaya jaye.\n\n` +
            `<i>Admin banao → phir command use karo!</i>`,
            { parse_mode: "HTML" },
          );
        }
        return;
      }
    }

    // Owner and sudo users bypass join requirement
    if (isOwner(String(ctx.from.id)) || (await isSudoAdmin(String(ctx.from.id)))) {
      return next();
    }

    // Extract command from text
    const text = ctx.message && "text" in ctx.message ? ctx.message.text : "";
    const cmdText = text.trim().split(/\s+/)[0] ?? "";
    const cmd = cmdText.split(/[\s@]/)[0]!.toLowerCase();

    // Commands that don't require join
    const freeCommands = ["/start", "/help"];
    if (freeCommands.includes(cmd)) return next();

    // Private chat join check only
    if (!isGroup) {
      const [inSupport, inUpdates] = await Promise.all([
        checkMembership(ctx.from.id, SUPPORT_GROUP_ID),
        checkMembership(ctx.from.id, UPDATES_CHANNEL_ID),
      ]);

      if (!inSupport || !inUpdates) {
        const missing: string[] = [];
        if (!inSupport) missing.push(`👥 <a href="${SUPPORT_GROUP_LINK}">Support Group</a>`);
        if (!inUpdates) missing.push(`📢 <a href="${UPDATES_CHANNEL_LINK}">Updates Channel</a>`);

        await ctx.reply(
          `⚠️ <b>Join Required!</b>\n\nPlease join before using the bot:\n\n${missing.join("\n")}\n\n<i>After joining, try your command again.</i>`,
          { parse_mode: "HTML", link_preview_options: { is_disabled: true } },
        );
        return;
      }
    }

    return next();
  });

  // ─── Commands ────────────────────────────────────────────────────────────────

  bot.command("start", handleStart);
  bot.command("help", handleHelp);

  bot.command(["harem", "collection"], handleHarem);
  bot.command(["bal", "balance", "coins"], handleBal);
  bot.command("pay", handlePay);
  bot.command("daily", handleDaily);
  bot.command("drop", handleDrop);
  bot.command(["view", "card"], handleView);
  bot.command(["profile", "me"], handleProfile);
  bot.command("search", handleSearch);
  bot.command("top", handleTop);
  bot.command("ctop", handleCtop);
  bot.command("stats", handleStats);
  bot.command("streak", handleStreak);
  bot.command("check", handleCheck);
  bot.command("fav", handleFav);
  bot.command("gift", handleGift);
  bot.command("burn", handleBurn);
  bot.command("trade", handleTrade);
  bot.command("warn", handleWarn);
  bot.command("warns", handleWarns);
  bot.command("unwarn", handleUnwarn);
  bot.command("resetwarns", handleResetWarns);
  bot.command(["jackpot", "jk"], handleJackpot);
  bot.command("redeem", handleRedeem);
  bot.command("gen", handleGen);
  bot.command("codelist", handleCodeList);
  bot.command("delcode", handleDelCode);
  bot.command("premium", handlePremium);
  bot.command("buypremium", handleBuyPremium);
  bot.command("sudo", handleSudo);
  bot.command("addsudo", handleAddSudo);
  bot.command("removesudo", handleRemoveSudo);
  bot.command("sudolist", handleSudoList);
  bot.command("spawntime", handleSpawnTime);
  bot.command("setmsgspawn", handleSetMsgSpawn);
  bot.command("setspawntime", handleSetSpawnTime);
  bot.command(["superbonus", "sb"], handleSuperBonus);
  bot.command("announce", handleAnnounce);

  // /name command — catch active spawned character
  bot.command("name", async (ctx) => {
    if (!ctx.from || ctx.from.is_bot) return;
    const chat = ctx.chat;
    if (!chat || (chat.type !== "group" && chat.type !== "supergroup")) {
      await ctx.reply(`⚠️ <b>/name sirf group mein use hota hai!</b>`, { parse_mode: "HTML" });
      return;
    }
    const args = ctx.message.text.split(/\s+/).slice(1).join(" ").trim();
    if (!args) {
      await ctx.reply(
        `ℹ️ <b>Usage:</b> /name [character name]\n\n<i>Example: /name Naruto</i>`,
        { parse_mode: "HTML" },
      );
      return;
    }
    await handleNameCommand(bot, String(chat.id), args, ctx.from, chat.id);
  });

  // ─── Callbacks ───────────────────────────────────────────────────────────────

  bot.action(/^help_(.+)$/, handleHelpCallback as (ctx: Context) => Promise<void>);
  bot.action(/^harem_(\d+)_(\d+)$/, handleHaremCallback as (ctx: Context) => Promise<void>);
  bot.action(/^fav_toggle_(\d+)_(\d+)_(\d+)$/, handleFavToggleCallback as (ctx: Context) => Promise<void>);
  bot.action(/^burn_confirm_(\d+)_(\d+)$/, handleBurnConfirm as (ctx: Context) => Promise<void>);
  bot.action("burn_cancel", handleBurnCancel);
  bot.action(/^trade_accept_(\d+)_(\d+)$/, handleTradeAccept as (ctx: Context) => Promise<void>);
  bot.action(/^trade_decline_(\d+)_(\d+)$/, handleTradeDecline as (ctx: Context) => Promise<void>);
  bot.action("buy_premium_info", handleBuyPremiumCallback);
  bot.action("quick_superbonus", handleSuperBonus);
  bot.action("noop", async (ctx) => { await ctx.answerCbQuery(); });

  // ─── Group message handler ────────────────────────────────────────────────────

  bot.on("message", async (ctx) => {
    if (!ctx.from || ctx.from.is_bot) return;
    const chat = ctx.chat;
    if (!chat || (chat.type !== "group" && chat.type !== "supergroup")) return;

    const msg = ctx.message;
    const text = "text" in msg ? msg.text : "";
    if (!text || text.startsWith("/")) return;

    await handleGroupMessage(bot, String(chat.id), text, ctx.from, chat.id);
  });

  // Set bot command menu (visible in chat input)
  try {
    await bot.telegram.setMyCommands([
      { command: "start",    description: "Start the bot & welcome menu" },
      { command: "help",     description: "Help & command list" },
      { command: "harem",    description: "View your character collection" },
      { command: "balance",  description: "Check your coin balance" },
      { command: "daily",    description: "Claim daily coin reward" },
      { command: "streak",   description: "View your daily streak" },
      { command: "top",      description: "Global top hunters leaderboard" },
      { command: "ctop",     description: "Group top hunters leaderboard" },
      { command: "profile",  description: "View your profile" },
      { command: "search",   description: "Search characters by name" },
      { command: "view",     description: "View a character card by ID" },
      { command: "fav",      description: "Favourite a character" },
      { command: "gift",     description: "Gift a character to someone" },
      { command: "burn",     description: "Burn a character for coins" },
      { command: "trade",    description: "Trade characters with someone" },
      { command: "drop",     description: "Force-spawn a character (admin)" },
      { command: "pay",      description: "Send coins to another user" },
      { command: "jackpot",  description: "Play the jackpot slot machine" },
      { command: "redeem",   description: "Redeem a code for rewards" },
      { command: "check",    description: "Check another user's profile" },
      { command: "stats",    description: "View global bot statistics" },
      { command: "premium",    description: "View / manage premium membership" },
      { command: "superbonus", description: "Claim a free character every 24 hours" },
    ]);
    logger.info("Bot commands registered");
  } catch (err) {
    logger.error({ err }, "Failed to set bot commands");
  }

  // Seed characters if DB is empty
  try {
    await seedCharacters();
  } catch (err) {
    logger.error({ err }, "Failed to seed characters");
  }

  // Cleanup expired spawns every minute
  setInterval(() => {
    cleanupExpiredSpawns(bot).catch((err: unknown) => logger.error({ err }, "Cleanup error"));
  }, 60_000);

  // Start polling
  bot.launch({ allowedUpdates: ["message", "callback_query", "my_chat_member"] });
  logger.info("Telegram bot started with polling");

  // Graceful shutdown
  process.once("SIGINT", () => { bot.stop("SIGINT"); });
  process.once("SIGTERM", () => { bot.stop("SIGTERM"); });
}
