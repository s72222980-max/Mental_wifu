import { db } from "@workspace/db";
import {
  botCharactersTable,
  botActiveSpawnsTable,
  botGroupStatsTable,
  botGroupSettingsTable,
  botUsersTable,
  botUserCharactersTable,
  botGroupCatchesTable,
  type BotActiveSpawn,
  type BotCharacter,
} from "@workspace/db";
import { eq, and, lt, isNull, or, gt, count } from "drizzle-orm";
import { sql } from "drizzle-orm";
import type { Telegraf } from "telegraf";
import { logger } from "../lib/logger";
import {
  getRarityEmoji,
  getRarityLabel,
  getRarityCoins,
  escapeHtml,
  generateNameHint,
  protectName,
  checkPremium,
  checkBanned,
  getOrCreateUser,
  PE,
  type TelegramFrom,
} from "./utils";

const SPAWN_TIMEOUT_MS = 90_000;
const DEFAULT_MSG_SPAWN = 20;
const PREMIUM_MSG_SPAWN = 15;

export interface ActiveSpawnWithCharacter extends BotActiveSpawn {
  character: BotCharacter;
}

export async function getActiveSpawnForGroup(groupId: string): Promise<ActiveSpawnWithCharacter | null> {
  const rows = await db
    .select({
      id: botActiveSpawnsTable.id,
      groupId: botActiveSpawnsTable.groupId,
      characterId: botActiveSpawnsTable.characterId,
      messageId: botActiveSpawnsTable.messageId,
      spawnedAt: botActiveSpawnsTable.spawnedAt,
      caught: botActiveSpawnsTable.caught,
      character: botCharactersTable,
    })
    .from(botActiveSpawnsTable)
    .innerJoin(botCharactersTable, eq(botActiveSpawnsTable.characterId, botCharactersTable.id))
    .where(and(eq(botActiveSpawnsTable.groupId, groupId), eq(botActiveSpawnsTable.caught, false)))
    .limit(1);
  return rows[0] ? { ...rows[0] } : null;
}

export async function pickRandomCharacter(): Promise<BotCharacter | null> {
  const roll = Math.random() * 100;
  let rarity: string;
  if (roll < 55) rarity = "common";
  else if (roll < 80) rarity = "rare";
  else if (roll < 95) rarity = "epic";
  else rarity = "legendary";

  const chars = await db.select().from(botCharactersTable).where(eq(botCharactersTable.rarity, rarity)).orderBy(sql`RANDOM()`).limit(1);
  if (chars.length > 0) return chars[0]!;
  const fallback = await db.select().from(botCharactersTable).orderBy(sql`RANDOM()`).limit(1);
  return fallback[0] ?? null;
}

export async function spawnCharacter(bot: Telegraf, groupId: string): Promise<void> {
  const existing = await getActiveSpawnForGroup(groupId);
  if (existing) return;

  const character = await pickRandomCharacter();
  if (!character) { logger.warn("No characters in DB, skipping spawn"); return; }

  const caption =
    `${PE.lightning} <b>A Wild Character Appeared!</b>\n\n` +
    `🎭 <b>Anime:</b> ${escapeHtml(character.anime)}\n` +
    `${getRarityEmoji(character.rarity)} <b>Rarity:</b> ${getRarityLabel(character.rarity)}\n\n` +
    `${PE.sword} <b>Use</b> /name [character name] <b>to catch!</b>\n` +
    `<blockquote>${PE.hourglass} 90 seconds to snatch!</blockquote>`;

  let msg: { message_id: number };
  try {
    msg = await bot.telegram.sendPhoto(groupId, character.imageUrl, { caption, parse_mode: "HTML" });
  } catch (err) {
    logger.error({ err, groupId }, "Failed to send spawn photo");
    return;
  }

  await db.insert(botActiveSpawnsTable).values({ groupId, characterId: character.id, messageId: msg.message_id });
  await db.update(botGroupStatsTable).set({ lastSpawnAt: new Date(), messageCount: 0 }).where(eq(botGroupStatsTable.groupId, groupId));
  logger.info({ groupId, character: character.name, rarity: character.rarity }, "Character spawned");
}

export async function handleGroupMessage(
  bot: Telegraf,
  groupId: string,
  _text: string,
  from: TelegramFrom,
  chatId: number,
): Promise<void> {
  if (await checkBanned(String(from.id))) return;

  const spawn = await getActiveSpawnForGroup(groupId);
  const shouldSpawn = await incrementGroupMessages(groupId);
  if (shouldSpawn && !spawn) {
    await spawnCharacter(bot, groupId);
  }
}

export async function handleNameCommand(
  bot: Telegraf,
  groupId: string,
  guessedName: string,
  from: TelegramFrom,
  chatId: number,
): Promise<void> {
  if (await checkBanned(String(from.id))) return;

  const spawn = await getActiveSpawnForGroup(groupId);

  if (!spawn || spawn.caught) {
    await bot.telegram.sendMessage(chatId,
      `👻 <b>Abhi koi character nahi aaya!</b>\n<i>Ruko, jald hi koi spawn hoga...</i>`,
      { parse_mode: "HTML" },
    );
    return;
  }

  if (guessedName.trim().toLowerCase() === spawn.character.name.toLowerCase()) {
    await catchCharacter(bot, spawn, from, chatId, groupId);
  } else {
    await bot.telegram.sendMessage(chatId,
      `${PE.cross} <b>${escapeHtml(from.first_name)}</b>, galat naam!\n<i>Dobara socho aur try karo 🤔</i>`,
      { parse_mode: "HTML" },
    );
  }
}

async function catchCharacter(bot: Telegraf, spawn: ActiveSpawnWithCharacter, from: TelegramFrom, chatId: number, groupId: string): Promise<void> {
  const user = await getOrCreateUser(from);
  const character = spawn.character;

  await db.update(botActiveSpawnsTable).set({ caught: true }).where(eq(botActiveSpawnsTable.id, spawn.id));

  const dupeRows = await db.select({ count: count() }).from(botUserCharactersTable)
    .where(and(eq(botUserCharactersTable.userId, user.id), eq(botUserCharactersTable.characterId, character.id)));
  const alreadyHas = Number(dupeRows[0]?.count ?? 0);

  const [newUc] = await db.insert(botUserCharactersTable).values({ userId: user.id, characterId: character.id }).returning();

  const isPremium = await checkPremium(String(from.id));
  const baseCoins = getRarityCoins(character.rarity);
  const coins = isPremium ? baseCoins * 2 : baseCoins;
  const premiumStr = isPremium ? " 🌟" : "";

  await db.update(botUsersTable).set({ totalCaught: user.totalCaught + 1, coins: user.coins + coins }).where(eq(botUsersTable.id, user.id));

  await db.insert(botGroupCatchesTable).values({ groupId, userId: user.id, caughtCount: 1 })
    .onConflictDoUpdate({
      target: [botGroupCatchesTable.groupId, botGroupCatchesTable.userId],
      set: { caughtCount: sql`${botGroupCatchesTable.caughtCount} + 1` },
    });

  // Edit the spawn card caption — use protectName so the name can't be copy-pasted from here
  try {
    await bot.telegram.editMessageCaption(chatId, spawn.messageId, undefined,
      `${PE.check} <b>${escapeHtml(from.first_name)}${premiumStr}</b> snatched <b>${protectName(escapeHtml(character.name))}</b>!`,
      { parse_mode: "HTML" },
    );
  } catch {}

  const dupeNote = alreadyHas > 0 ? `\n🔄 <i>Duplicate! (${alreadyHas + 1} copies)</i>` : "";

  // Send catch result text
  await bot.telegram.sendMessage(chatId,
    `${PE.party} <b>${escapeHtml(from.first_name)}${premiumStr}</b> caught <b>${protectName(escapeHtml(character.name))}</b>!\n\n` +
      `🎭 <b>Anime:</b> ${escapeHtml(character.anime)}\n` +
      `${getRarityEmoji(character.rarity)} <b>Rarity:</b> ${getRarityLabel(character.rarity)}\n` +
      `${PE.coin} <b>Coins:</b> +${coins}${isPremium ? ` (2x ${PE.crown}Premium!)` : ""}${dupeNote}\n\n` +
      `<blockquote>Use /harem to view your collection!</blockquote>`,
    { parse_mode: "HTML" },
  );

  // Send character card to the catcher (harem-style photo card)
  const ucId = newUc?.id ?? 0;
  const cardCaption =
    `${PE.cherry} <b>New character added to your harem!</b>\n\n` +
    `${getRarityEmoji(character.rarity)} <b>${escapeHtml(character.name)}</b>\n` +
    `🎭 <b>Anime:</b> ${escapeHtml(character.anime)}\n` +
    `${PE.sparkles} <b>Rarity:</b> ${getRarityLabel(character.rarity)}\n` +
    `🆔 <b>Collection ID:</b> #${ucId}\n\n` +
    `<blockquote>Use /view ${ucId} to see it anytime!</blockquote>`;

  try {
    await bot.telegram.sendPhoto(chatId, character.imageUrl, {
      caption: cardCaption,
      parse_mode: "HTML",
    });
  } catch {}

  logger.info({ user: from.first_name, character: character.name }, "Character caught");
}

async function getGroupMsgSpawnCount(groupId: string): Promise<number> {
  const rows = await db.select({ msgSpawnCount: botGroupSettingsTable.msgSpawnCount, isPremium: botGroupSettingsTable.isPremium })
    .from(botGroupSettingsTable).where(eq(botGroupSettingsTable.groupId, groupId)).limit(1);
  const settings = rows[0];
  if (!settings) return DEFAULT_MSG_SPAWN;
  return settings.isPremium ? Math.min(settings.msgSpawnCount, PREMIUM_MSG_SPAWN) : settings.msgSpawnCount;
}

async function incrementGroupMessages(groupId: string): Promise<boolean> {
  const spawnCount = await getGroupMsgSpawnCount(groupId);

  // Upsert — prevents duplicate key crash on concurrent first messages
  await db.insert(botGroupStatsTable)
    .values({ groupId, messageCount: 1, lastActivityAt: new Date() })
    .onConflictDoUpdate({
      target: botGroupStatsTable.groupId,
      set: { messageCount: sql`${botGroupStatsTable.messageCount} + 1`, lastActivityAt: new Date() },
    });

  const existing = await db.select().from(botGroupStatsTable).where(eq(botGroupStatsTable.groupId, groupId)).limit(1);
  if (!existing[0]) return false;

  const stats = existing[0]!;

  const settingsRows = await db.select().from(botGroupSettingsTable).where(eq(botGroupSettingsTable.groupId, groupId)).limit(1);
  const spawnIntervalMins = settingsRows[0]?.spawnIntervalMins ?? null;

  // stats.messageCount already has the incremented value from the upsert above
  const countBased = !spawnIntervalMins && stats.messageCount >= spawnCount;
  const timeBased = spawnIntervalMins
    ? stats.lastSpawnAt !== null && stats.lastSpawnAt < new Date(Date.now() - spawnIntervalMins * 60 * 1000)
    : (stats.lastSpawnAt !== null && stats.lastSpawnAt < new Date(Date.now() - 30 * 60 * 1000));

  if (countBased || timeBased) {
    await db.update(botGroupStatsTable).set({ messageCount: 0 }).where(eq(botGroupStatsTable.groupId, groupId));
    return true;
  }

  return false;
}

export async function cleanupExpiredSpawns(bot: Telegraf): Promise<void> {
  const cutoff = new Date(Date.now() - SPAWN_TIMEOUT_MS);
  const expired = await db
    .select({ id: botActiveSpawnsTable.id, groupId: botActiveSpawnsTable.groupId, messageId: botActiveSpawnsTable.messageId, characterName: botCharactersTable.name })
    .from(botActiveSpawnsTable)
    .innerJoin(botCharactersTable, eq(botActiveSpawnsTable.characterId, botCharactersTable.id))
    .where(and(eq(botActiveSpawnsTable.caught, false), lt(botActiveSpawnsTable.spawnedAt, cutoff)));

  for (const spawn of expired) {
    try {
      await bot.telegram.editMessageCaption(spawn.groupId, spawn.messageId, undefined,
        `${PE.hourglass} Time's up! <b>${escapeHtml(spawn.characterName)}</b> escaped!\n<blockquote>No one was fast enough... Next time be quicker!</blockquote>`,
        { parse_mode: "HTML" },
      );
    } catch {}
    await db.delete(botActiveSpawnsTable).where(eq(botActiveSpawnsTable.id, spawn.id));
  }
}

export async function triggerTimedSpawns(bot: Telegraf): Promise<void> {
  const thirtyMinAgo = new Date(Date.now() - 30 * 60 * 1000);
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);

  const groups = await db.select().from(botGroupStatsTable)
    .where(and(gt(botGroupStatsTable.lastActivityAt, oneHourAgo), or(isNull(botGroupStatsTable.lastSpawnAt), lt(botGroupStatsTable.lastSpawnAt, thirtyMinAgo))));

  for (const group of groups) {
    const active = await getActiveSpawnForGroup(group.groupId);
    if (!active) await spawnCharacter(bot, group.groupId);
  }
}
