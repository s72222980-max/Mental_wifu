import { db } from "@workspace/db";
import { botCharactersTable, botActiveSpawnsTable, botTradesTable, botUserCharactersTable } from "@workspace/db";
import { count } from "drizzle-orm";
import { logger } from "../lib/logger";

const ANILIST_URL = "https://graphql.anilist.co";
const CHARS_PER_ANIME = 8;
const BATCH_SIZE = 7;

const ANIME_LIST = [
  "Naruto", "One Piece", "Attack on Titan", "Demon Slayer", "My Hero Academia",
  "Dragon Ball Z", "Fullmetal Alchemist Brotherhood", "Death Note", "Hunter x Hunter",
  "Bleach", "Sword Art Online", "Re:Zero", "Overlord", "That Time I Got Reincarnated as a Slime",
  "Black Clover", "Fairy Tail", "Tokyo Ghoul", "No Game No Life", "Danmachi",
  "Log Horizon", "Sword Art Online Alicization", "Jujutsu Kaisen", "Chainsaw Man",
  "Spy x Family", "Vinland Saga", "Violet Evergarden", "Your Name", "Weathering With You",
  "A Silent Voice", "Toradora", "Clannad", "Anohana", "Steins;Gate",
  "The Promised Neverland", "Mob Psycho 100", "One Punch Man", "Konosuba", "Overlord",
  "Sword Art Online: Alicization", "Nanatsu no Taizai", "Black Clover", "Fire Force",
  "Dr. Stone", "Haikyuu", "Kuroko no Basket", "Slam Dunk", "Hajime no Ippo",
  "Evangelion", "Fate/Zero", "Fate/Stay Night", "Code Geass", "Gurren Lagann",
  "Cowboy Bebop", "Trigun", "Rurouni Kenshin", "Yu Yu Hakusho", "Dragon Ball Super",
  "Sword Art Online: Progressive", "Mushoku Tensei", "Tensura", "Arifureta",
  "Shield Hero", "Danmachi", "Quintessential Quintuplets", "The Irregular at Magic High School",
  "Mahou Shoujo Madoka Magica", "Puella Magi Madoka Magica", "Angel Beats",
  "Sword Art Online: Alicization - War of Underworld", "Wotaku ni Koi wa Muzukashii",
  "Kaguya-sama: Love is War", "My Dress-Up Darling", "Oshi no Ko",
  "Bocchi the Rock", "Lycoris Recoil", "Blue Lock",
];

interface AniListNode {
  id: number;
  name: { full: string };
  favourites: number;
  image: { large: string };
}

interface BatchResult {
  [key: string]: {
    title: { romaji: string; english: string | null };
    characters: { nodes: AniListNode[] };
  } | null;
}

function buildBatchQuery(titles: string[]): string {
  const fields = titles
    .map((title, i) => {
      const escaped = title.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
      return `
      a${i}: Media(search: "${escaped}", type: ANIME) {
        title { romaji english }
        characters(sort: FAVOURITES_DESC, page: 1, perPage: ${CHARS_PER_ANIME}) {
          nodes { id name { full } favourites image { large } }
        }
      }`;
    })
    .join("\n");
  return `query { ${fields} }`;
}

async function fetchBatch(titles: string[]): Promise<BatchResult> {
  const query = buildBatchQuery(titles);
  const res = await fetch(ANILIST_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ query }),
  });
  if (!res.ok) throw new Error(`AniList API error: ${res.status}`);
  const json = (await res.json()) as { data: BatchResult };
  return json.data;
}

function assignRarity(favourites: number): string {
  if (favourites >= 50_000) return "legendary";
  if (favourites >= 10_000) return "epic";
  if (favourites >= 2_000) return "rare";
  return "common";
}

export async function seedCharacters(): Promise<void> {
  const existing = await db.select({ count: count() }).from(botCharactersTable);
  if (Number(existing[0]?.count ?? 0) > 0) {
    logger.info({ count: existing[0]?.count }, "Characters already seeded, skipping");
    return;
  }
  await doSeed();
}

export async function reseedCharacters(): Promise<void> {
  logger.info("Reseeding characters — clearing old data...");
  await db.delete(botActiveSpawnsTable);
  await db.delete(botTradesTable);
  await db.delete(botUserCharactersTable);
  await db.delete(botCharactersTable);
  await doSeed();
}

async function doSeed(): Promise<void> {
  logger.info({ animeCount: ANIME_LIST.length }, "Seeding characters from specific anime list...");

  const seenIds = new Set<number>();
  const toInsert: {
    name: string;
    anime: string;
    imageUrl: string;
    rarity: string;
    anilistId: number;
    favourites: number;
  }[] = [];

  for (let i = 0; i < ANIME_LIST.length; i += BATCH_SIZE) {
    const batch = ANIME_LIST.slice(i, i + BATCH_SIZE);
    try {
      const result = await fetchBatch(batch);
      let added = 0;
      for (let j = 0; j < batch.length; j++) {
        const mediaData = result[`a${j}`];
        if (!mediaData) continue;
        const animeName = mediaData.title.english ?? mediaData.title.romaji;
        for (const char of mediaData.characters.nodes) {
          if (seenIds.has(char.id)) continue;
          if (!char.name?.full) continue;
          if (!char.image?.large || char.image.large.includes("default")) continue;
          seenIds.add(char.id);
          toInsert.push({
            name: char.name.full,
            anime: animeName,
            imageUrl: char.image.large,
            rarity: assignRarity(char.favourites),
            anilistId: char.id,
            favourites: char.favourites,
          });
          added++;
        }
      }
      logger.info({ batch: Math.floor(i / BATCH_SIZE) + 1, added, total: toInsert.length }, "Processed anime batch");
      await new Promise((r) => setTimeout(r, 700));
    } catch (err) {
      logger.error({ err, batch }, "Failed to fetch batch");
      await new Promise((r) => setTimeout(r, 1500));
    }
  }

  if (toInsert.length === 0) {
    logger.warn("No characters to seed");
    return;
  }

  await db.insert(botCharactersTable).values(toInsert);
  logger.info({ count: toInsert.length }, "Characters seeded from specific anime list");
}
