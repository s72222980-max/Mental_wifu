import { db } from "@workspace/db";
import {
  botUsersTable,
  botPremiumUsersTable,
  botBannedUsersTable,
  botSudoUsersTable,
  type BotUser,
} from "@workspace/db";
import { eq, and, isNull, or, gt } from "drizzle-orm";

export interface TelegramFrom {
  id: number;
  first_name: string;
  username?: string;
  is_bot?: boolean;
}

export async function getOrCreateUser(from: TelegramFrom): Promise<BotUser> {
  const { user } = await getOrCreateUserWithStatus(from);
  return user;
}

export async function getOrCreateUserWithStatus(from: TelegramFrom): Promise<{ user: BotUser; isNew: boolean }> {
  const tid = String(from.id);
  const existing = await db.select().from(botUsersTable).where(eq(botUsersTable.telegramId, tid)).limit(1);
  if (existing.length > 0) {
    const user = existing[0]!;
    if (user.username !== (from.username ?? null) || user.firstName !== from.first_name) {
      await db.update(botUsersTable)
        .set({ username: from.username ?? null, firstName: from.first_name })
        .where(eq(botUsersTable.id, user.id));
      return { user: { ...user, username: from.username ?? null, firstName: from.first_name }, isNew: false };
    }
    return { user, isNew: false };
  }
  const [newUser] = await db.insert(botUsersTable)
    .values({ telegramId: tid, username: from.username ?? null, firstName: from.first_name })
    .returning();
  return { user: newUser!, isNew: true };
}

export async function getUserByTelegramId(telegramId: string): Promise<BotUser | null> {
  const rows = await db.select().from(botUsersTable).where(eq(botUsersTable.telegramId, telegramId)).limit(1);
  return rows[0] ?? null;
}

export async function getUserByUsername(username: string): Promise<BotUser | null> {
  const rows = await db.select().from(botUsersTable).where(eq(botUsersTable.username, username)).limit(1);
  return rows[0] ?? null;
}

export async function checkPremium(telegramId: string): Promise<boolean> {
  const rows = await db.select({ t: botPremiumUsersTable.telegramId })
    .from(botPremiumUsersTable)
    .where(and(
      eq(botPremiumUsersTable.telegramId, telegramId),
      or(isNull(botPremiumUsersTable.expiresAt), gt(botPremiumUsersTable.expiresAt, new Date())),
    ))
    .limit(1);
  return rows.length > 0;
}

export async function checkBanned(telegramId: string): Promise<boolean> {
  const rows = await db.select({ t: botBannedUsersTable.telegramId })
    .from(botBannedUsersTable)
    .where(eq(botBannedUsersTable.telegramId, telegramId))
    .limit(1);
  return rows.length > 0;
}

export function isOwner(telegramId: string): boolean {
  const ownerId = process.env.OWNER_ID;
  return !!ownerId && telegramId === ownerId;
}

export async function isSudoAdmin(telegramId: string): Promise<boolean> {
  if (isOwner(telegramId)) return true;
  const rows = await db.select({ t: botSudoUsersTable.telegramId })
    .from(botSudoUsersTable)
    .where(eq(botSudoUsersTable.telegramId, telegramId))
    .limit(1);
  return rows.length > 0;
}

export async function isGroupAdmin(ctx: {
  telegram: { getChatMember: (chatId: number | string, userId: number) => Promise<{ status: string }> };
  chat?: { id: number; type: string } | null;
  from?: { id: number } | null;
}): Promise<boolean> {
  if (!ctx.from || !ctx.chat) return false;
  if (ctx.chat.type !== "group" && ctx.chat.type !== "supergroup") return false;
  try {
    const member = await ctx.telegram.getChatMember(ctx.chat.id, ctx.from.id);
    return member.status === "administrator" || member.status === "creator";
  } catch {
    return false;
  }
}

// Telegram Premium Custom Emoji IDs
// These use <tg-emoji> tags — visible as animated emoji for Telegram Premium users
// fallback plain emoji shown to non-premium users
export const PE = {
  star:      `<tg-emoji emoji-id="5368324170671202286">⭐</tg-emoji>`,
  fire:      `<tg-emoji emoji-id="5199885118214255386">🔥</tg-emoji>`,
  gem:       `<tg-emoji emoji-id="5471952986970267163">💎</tg-emoji>`,
  crown:     `<tg-emoji emoji-id="5440539497383087970">👑</tg-emoji>`,
  sparkles:  `<tg-emoji emoji-id="5467666648263564704">✨</tg-emoji>`,
  coin:      `<tg-emoji emoji-id="5282648845595060508">🪙</tg-emoji>`,
  heart:     `<tg-emoji emoji-id="5346325515611070263">💖</tg-emoji>`,
  lightning: `<tg-emoji emoji-id="5199767736765783980">⚡</tg-emoji>`,
  trophy:    `<tg-emoji emoji-id="5471979925362094439">🏆</tg-emoji>`,
  gift:      `<tg-emoji emoji-id="5381013491334001879">🎁</tg-emoji>`,
  cherry:    `<tg-emoji emoji-id="5355305987550943616">🌸</tg-emoji>`,
  legendary: `<tg-emoji emoji-id="5431815452437257407">🌟</tg-emoji>`,
  epic:      `<tg-emoji emoji-id="5471952986970267163">💜</tg-emoji>`,
  rare:      `<tg-emoji emoji-id="5361541227604878624">💙</tg-emoji>`,
  common:    `<tg-emoji emoji-id="5361731625469032991">🤍</tg-emoji>`,
  sword:     `<tg-emoji emoji-id="5199706734157180399">⚔️</tg-emoji>`,
  dice:      `<tg-emoji emoji-id="5213183776738743296">🎲</tg-emoji>`,
  lock:      `<tg-emoji emoji-id="5447410659077661506">🔒</tg-emoji>`,
  check:     `<tg-emoji emoji-id="5439870505053786924">✅</tg-emoji>`,
  cross:     `<tg-emoji emoji-id="5465665476971471368">❌</tg-emoji>`,
  rocket:    `<tg-emoji emoji-id="5199878157534488579">🚀</tg-emoji>`,
  party:     `<tg-emoji emoji-id="5373026167722876724">🎉</tg-emoji>`,
  hourglass: `<tg-emoji emoji-id="5199819630990017749">⏳</tg-emoji>`,
  warning:   `<tg-emoji emoji-id="5462882007451037407">⚠️</tg-emoji>`,
};

export function getRarityEmoji(rarity: string): string {
  switch (rarity) {
    case "legendary": return PE.legendary;
    case "epic":      return PE.epic;
    case "rare":      return PE.rare;
    default:          return PE.common;
  }
}

export function getRarityLabel(rarity: string): string {
  switch (rarity) {
    case "legendary": return `${PE.legendary} LEGENDARY`;
    case "epic":      return `${PE.epic} EPIC`;
    case "rare":      return `${PE.rare} RARE`;
    default:          return `${PE.common} COMMON`;
  }
}

export function getRarityCoins(rarity: string): number {
  switch (rarity) {
    case "legendary": return 100;
    case "epic":      return 30;
    case "rare":      return 15;
    default:          return 5;
  }
}

export function getBurnCoins(rarity: string): number {
  switch (rarity) {
    case "legendary": return 50;
    case "epic":      return 15;
    case "rare":      return 7;
    default:          return 2;
  }
}

export function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export function generateNameHint(name: string): string {
  return name.split(" ").map((word) => {
    if (word.length <= 2) return word;
    const chars = [...word];
    return chars.map((c, i) => (i === 0 || i === chars.length - 1 ? c : "_")).join(" ");
  }).join("   ");
}

// Insert zero-width space between characters to prevent copy-paste cheating
export function protectName(name: string): string {
  return [...name].join("\u200B");
}

export function formatDate(date: Date): string {
  return date.toLocaleDateString("en-US", { day: "2-digit", month: "short", year: "numeric" });
}
