import { pgTable, serial, text, integer, boolean, timestamp, unique } from "drizzle-orm/pg-core";

export const botUsersTable = pgTable("bot_users", {
  id: serial("id").primaryKey(),
  telegramId: text("telegram_id").notNull().unique(),
  username: text("username"),
  firstName: text("first_name").notNull(),
  coins: integer("coins").notNull().default(0),
  totalCaught: integer("total_caught").notNull().default(0),
  streakDays: integer("streak_days").notNull().default(0),
  lastDailyAt: timestamp("last_daily_at"),
  lastSuperBonusAt: timestamp("last_super_bonus_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type BotUser = typeof botUsersTable.$inferSelect;
export type InsertBotUser = typeof botUsersTable.$inferInsert;

export const botCharactersTable = pgTable("bot_characters", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  anime: text("anime").notNull(),
  imageUrl: text("image_url").notNull(),
  rarity: text("rarity").notNull().default("common"),
  anilistId: integer("anilist_id").notNull().default(0),
  favourites: integer("favourites").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type BotCharacter = typeof botCharactersTable.$inferSelect;

export const botActiveSpawnsTable = pgTable("bot_active_spawns", {
  id: serial("id").primaryKey(),
  groupId: text("group_id").notNull(),
  characterId: integer("character_id").notNull(),
  messageId: integer("message_id").notNull(),
  spawnedAt: timestamp("spawned_at").notNull().defaultNow(),
  caught: boolean("caught").notNull().default(false),
});

export type BotActiveSpawn = typeof botActiveSpawnsTable.$inferSelect;

export const botGroupStatsTable = pgTable("bot_group_stats", {
  id: serial("id").primaryKey(),
  groupId: text("group_id").notNull().unique(),
  messageCount: integer("message_count").notNull().default(0),
  lastSpawnAt: timestamp("last_spawn_at"),
  lastActivityAt: timestamp("last_activity_at").notNull().defaultNow(),
});

export const botGroupSettingsTable = pgTable("bot_group_settings", {
  id: serial("id").primaryKey(),
  groupId: text("group_id").notNull().unique(),
  msgSpawnCount: integer("msg_spawn_count").notNull().default(20),
  spawnIntervalMins: integer("spawn_interval_mins"),
  isPremium: boolean("is_premium").notNull().default(false),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const botGroupCatchesTable = pgTable("bot_group_catches", {
  id: serial("id").primaryKey(),
  groupId: text("group_id").notNull(),
  userId: integer("user_id").notNull(),
  caughtCount: integer("caught_count").notNull().default(0),
}, (t) => [unique().on(t.groupId, t.userId)]);

export const botUserCharactersTable = pgTable("bot_user_characters", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  characterId: integer("character_id").notNull(),
  isFavorite: boolean("is_favorite").notNull().default(false),
  caughtAt: timestamp("caught_at").notNull().defaultNow(),
});

export const botTradesTable = pgTable("bot_trades", {
  id: serial("id").primaryKey(),
  offererTelegramId: text("offerer_telegram_id").notNull(),
  receiverTelegramId: text("receiver_telegram_id").notNull(),
  offeredUserCharId: integer("offered_user_char_id").notNull(),
  wantedUserCharId: integer("wanted_user_char_id"),
  chatId: text("chat_id").notNull(),
  status: text("status").notNull().default("pending"),
  messageId: integer("message_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const botRedeemCodesTable = pgTable("bot_redeem_codes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  rewardCoins: integer("reward_coins").notNull(),
  maxUses: integer("max_uses").notNull(),
  usedCount: integer("used_count").notNull().default(0),
  expiresAt: timestamp("expires_at"),
  createdBy: text("created_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const botUserCodesTable = pgTable("bot_user_codes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  codeId: integer("code_id").notNull(),
  usedAt: timestamp("used_at").notNull().defaultNow(),
}, (t) => [unique().on(t.userId, t.codeId)]);

export const botPremiumUsersTable = pgTable("bot_premium_users", {
  id: serial("id").primaryKey(),
  telegramId: text("telegram_id").notNull().unique(),
  grantedBy: text("granted_by").notNull(),
  grantedAt: timestamp("granted_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at"),
});

export const botBannedUsersTable = pgTable("bot_banned_users", {
  id: serial("id").primaryKey(),
  telegramId: text("telegram_id").notNull().unique(),
  reason: text("reason"),
  bannedBy: text("banned_by").notNull(),
  bannedAt: timestamp("banned_at").notNull().defaultNow(),
});

export const botSudoUsersTable = pgTable("bot_sudo_users", {
  id: serial("id").primaryKey(),
  telegramId: text("telegram_id").notNull().unique(),
  grantedBy: text("granted_by").notNull(),
  grantedAt: timestamp("granted_at").notNull().defaultNow(),
});

export const botWarningsTable = pgTable("bot_warnings", {
  id: serial("id").primaryKey(),
  groupId: text("group_id").notNull(),
  telegramId: text("telegram_id").notNull(),
  reason: text("reason"),
  warnedBy: text("warned_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
